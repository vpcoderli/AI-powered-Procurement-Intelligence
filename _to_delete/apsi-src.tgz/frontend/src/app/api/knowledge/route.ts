import { NextResponse } from "next/server";
import {
  FeatureAccessError,
  featureErrorResponse,
  requireFeature,
} from "@/server/auth/feature-gate";
import { resolvePrincipal, type RequestPrincipal } from "@/server/auth/principal";
import { authRequiredResponse, isAuthenticatedPrincipal } from "@/server/auth/route-guards";
import { db, type AppDatabase } from "@/server/db/client";
import {
  createKnowledgeItem,
  KnowledgeValidationError,
  listKnowledgeItems,
} from "@/server/knowledge/service";
import { retrieveKnowledgeContext } from "@/server/knowledge/retrieval";

function jsonWithPrincipalCookie(
  body: unknown,
  principal: RequestPrincipal,
  init?: ResponseInit,
) {
  const response = NextResponse.json(body, init);

  if (principal.kind === "anonymous" && principal.anonymousCookie) {
    response.headers.append("Set-Cookie", principal.anonymousCookie);
  }

  return response;
}

function errorResponse(
  code: string,
  message: string,
  status: number,
  principal: RequestPrincipal,
) {
  return jsonWithPrincipalCookie({ error: { code, message } }, principal, { status });
}

function workspaceOrganizationId(principal: RequestPrincipal) {
  if (!isAuthenticatedPrincipal(principal)) return null;

  return principal.workspace?.organizationId ?? null;
}

function optionalQueryValue(value: string | null) {
  return value?.trim() || null;
}

function limitQueryValue(value: string | null) {
  if (!value) return null;

  const parsed = Number(value);

  return Number.isFinite(parsed) ? parsed : null;
}

function objectBody(body: unknown) {
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    return {};
  }

  return body as Record<string, unknown>;
}

export function createKnowledgeRouteHandlers(database: AppDatabase) {
  async function GET(request: Request) {
    const principal = await resolvePrincipal(database, request);
    const organizationId = workspaceOrganizationId(principal);

    if (!organizationId) {
      return authRequiredResponse();
    }

    try {
      requireFeature(principal, "knowledge_station");

      const searchParams = new URL(request.url).searchParams;
      const q = optionalQueryValue(searchParams.get("q"));
      const limit = limitQueryValue(searchParams.get("limit"));

      if (searchParams.get("includeRetrievalTrace") === "1" && q) {
        const result = await retrieveKnowledgeContext(database, {
          organizationId,
          query: q,
          limit,
        });

        return jsonWithPrincipalCookie({
          items: result.items,
          retrievalTrace: result.trace,
        }, principal);
      }

      const result = await listKnowledgeItems(database, {
        organizationId,
        intentId: optionalQueryValue(searchParams.get("intentId")),
        bidId: optionalQueryValue(searchParams.get("bidId")),
        q,
        type: optionalQueryValue(searchParams.get("type")),
        limit,
      });

      return jsonWithPrincipalCookie(result, principal);
    } catch (error) {
      if (error instanceof FeatureAccessError) {
        return NextResponse.json(featureErrorResponse(error), { status: error.status });
      }

      if (error instanceof KnowledgeValidationError) {
        return errorResponse("INVALID_REQUEST", error.message, 400, principal);
      }

      return errorResponse("INTERNAL_ERROR", "Internal server error", 500, principal);
    }
  }

  async function POST(request: Request) {
    const body = objectBody(await request.json().catch(() => null));
    const principal = await resolvePrincipal(database, request);
    const organizationId = workspaceOrganizationId(principal);

    if (!organizationId) {
      return authRequiredResponse();
    }

    try {
      requireFeature(principal, "knowledge_station");

      const item = await createKnowledgeItem(database, {
        organizationId,
        userId: principal.userId,
        title: body.title as string,
        body: body.body as string,
        type: body.type as string,
        tags: body.tags,
        sourceKind: body.sourceKind as string,
        sourceIntentId: body.sourceIntentId as string | null | undefined,
        sourceBidId: body.sourceBidId as string | null | undefined,
        sourceUrl: body.sourceUrl as string | null | undefined,
      });

      return jsonWithPrincipalCookie({ item }, principal, { status: 201 });
    } catch (error) {
      if (error instanceof FeatureAccessError) {
        return NextResponse.json(featureErrorResponse(error), { status: error.status });
      }

      if (error instanceof KnowledgeValidationError) {
        return errorResponse("INVALID_REQUEST", error.message, 400, principal);
      }

      return errorResponse("INTERNAL_ERROR", "Internal server error", 500, principal);
    }
  }

  return { GET, POST };
}

export const { GET, POST } = createKnowledgeRouteHandlers(db);
