"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { ArtifactVaultPanel } from "@/components/intents/ArtifactVaultPanel";
import type { ArtifactDraft } from "@/components/intents/ArtifactVaultPanel";
import { DeadlineNotificationsPanel } from "@/components/intents/DeadlineNotificationsPanel";
import { AwardWinLossPanel } from "@/components/intents/AwardWinLossPanel";
import { QuoteWorkspacePanel } from "@/components/intents/QuoteWorkspacePanel";
import type { QuoteDraft } from "@/components/intents/QuoteWorkspacePanel";
import { ResponseWorkspacePanel } from "@/components/intents/ResponseWorkspacePanel";
import { AuthRequiredState } from "@/components/auth/AuthRequiredState";
import { UniversalState } from "@/components/universal-state";
import {
  confirmSubmission,
  createResponsePackageExport,
  createResponsePackageSnapshot,
  createResponseWorkspaceComment,
  deleteSupplierArtifact,
  fetchAwardOutcome,
  fetchArtifactVault,
  fetchComplianceManifest,
  fetchDeadlineWorkspace,
  fetchIntent,
  fetchPursuitDecisionBoard,
  fetchQuoteWorkspace,
  fetchQualificationCitations,
  fetchQualificationFreshness,
  fetchResponsePackageWorkspace,
  fetchResponseWorkspaceComments,
  fetchResponseWorkspace,
  fetchSubmissionGuidance,
  createQuoteRequestDraft,
  postQualificationQuestion,
  refreshQualificationEvidence,
  replaceSupplierArtifact,
  updateComplianceManifestItem,
  updateIntentStatus,
  updateDeadlineReminder,
  updatePursuitDecision,
  updateQuoteRequestDraft,
  updateAwardOutcome,
  updateResponseWorkspaceItemArtifactLinks,
  updateResponseWorkspaceItem,
  updateResponsePackageExportReview,
  updateSubmissionGuidance,
  uploadSupplierArtifact,
} from "@/lib/api/intents";
import { createKnowledgeItem, fetchKnowledgeItems } from "@/lib/api/knowledge";
import { useAuth } from "@/context/AuthContext";
import { lockedFeatureMessage, useFeature } from "@/lib/features/useFeature";
import { useLanguage } from "@/lib/i18n/LanguageContext";
import { generateWorkflowCoachCards } from "@/lib/knowledge/coach";
import { safeKnowledgeSourceUrl } from "@/lib/knowledge/source-url";
import type { IntentDetail, IntentStatus } from "@/server/intents/types";
import { INTENT_STATUSES } from "@/server/intents/types";
import type { KnowledgeItem, KnowledgeRetrievalTrace, WorkflowCoachCard } from "@/server/knowledge/types";
import type {
  QualificationCitation,
  QualificationFreshnessResponse,
  QualificationQuestionResponse,
} from "@/server/qualification/types";
import type {
  ComplianceEvidenceStatus,
  ComplianceItemStatus,
  ComplianceManifest,
  ComplianceManifestItem,
} from "@/server/compliance/types";
import {
  COMPLIANCE_EVIDENCE_STATUSES,
  COMPLIANCE_ITEM_STATUSES,
} from "@/server/compliance/types";
import type {
  PursuitDecisionBoard,
  PursuitDecisionValue,
  PursuitEvidenceRef,
} from "@/server/pursuit/types";
import { PURSUIT_DECISIONS } from "@/server/pursuit/types";
import type {
  ResponseWorkspace,
  ResponseWorkspaceComment,
  ResponseWorkspaceItem,
  ResponsePackageExportFormat,
  ResponsePackageExportReviewStatus,
  ResponsePackageWorkspace,
} from "@/server/response-workspace/types";
import type { ArtifactVault } from "@/server/artifacts/types";
import type {
  QuoteRequest,
  QuoteRequestStatus,
  QuoteWorkspace,
} from "@/server/quotes/types";
import type {
  DeadlineReminder,
  DeadlineWorkspace,
} from "@/server/deadlines/types";
import type {
  AwardOutcome,
  UpdateAwardOutcomeInput,
} from "@/server/awards/types";
import type {
  SubmissionConfirmation,
  SubmissionEvidenceLinks,
  SubmissionGuidance,
  SubmissionMethod,
} from "@/server/submission/types";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  CalendarClock,
  CheckCircle2,
  ClipboardCheck,
  ExternalLink,
  FileCheck2,
  Gauge,
  Landmark,
  LockKeyhole,
  PackageCheck,
  RefreshCcw,
  Route,
  ShieldAlert,
  Sparkles,
  Target,
  Truck,
} from "lucide-react";

function scoreTone(score: number) {
  if (score >= 75) return "text-emerald-700 bg-emerald-50 border-emerald-200";
  if (score >= 50) return "text-amber-700 bg-amber-50 border-amber-200";
  return "text-slate-600 bg-slate-50 border-slate-200";
}

function metricLabel(key: string) {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, (value) => value.toUpperCase());
}

function safeEvidenceUrl(value: string) {
  return safeKnowledgeSourceUrl(value);
}

function safeSubmissionEvidenceUrl(value: string) {
  return value.startsWith("/") ? value : safeEvidenceUrl(value);
}

function evidenceRefUrl(ref: Pick<PursuitEvidenceRef, "url">) {
  return ref.url ? safeEvidenceUrl(ref.url) : "";
}

function artifactDownloadUrl(intentId: string, artifactId: string) {
  return `/api/intents/${encodeURIComponent(intentId)}/artifacts/${encodeURIComponent(artifactId)}`;
}

function formatEvidenceDate(value: string | null) {
  if (!value) return "";

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function formatCentsAmount(value: number | null, currency: string | null | undefined) {
  if (value === null) return "Not available";

  return `${currency || "USD"} ${(value / 100).toFixed(2)}`;
}

const emptySubmissionEvidenceLinks: SubmissionEvidenceLinks = {
  responsePackageExports: [],
  linkedSupplierArtifacts: [],
  awardOutcome: null,
};

type SubmissionEvidenceExport = SubmissionEvidenceLinks["responsePackageExports"][number] & {
  createdAt?: string;
  downloadedAt?: string | null;
  fileName?: string;
  sizeLabel?: string;
};

type SubmissionEvidenceArtifact = SubmissionEvidenceLinks["linkedSupplierArtifacts"][number] & {
  category?: string;
  downloadUrl?: string;
  fileName?: string;
  sizeLabel?: string;
  type?: string;
};

function hasSubmissionEvidenceLinks(evidenceLinks: SubmissionEvidenceLinks) {
  return (
    evidenceLinks.responsePackageExports.length > 0 ||
    evidenceLinks.linkedSupplierArtifacts.length > 0 ||
    Boolean(evidenceLinks.awardOutcome)
  );
}

function submissionEvidenceAutoLinkSummary(evidenceLinks: SubmissionEvidenceLinks) {
  const packageCount = evidenceLinks.responsePackageExports.length;
  const artifactCount = evidenceLinks.linkedSupplierArtifacts.length;
  const awardCount = evidenceLinks.awardOutcome ? 1 : 0;
  const totalLinks = packageCount + artifactCount + awardCount;

  if (totalLinks === 0) {
    return "No artifact/submission evidence auto-links yet.";
  }

  return `${totalLinks} artifact/submission evidence auto-links: ${packageCount} package exports, ${artifactCount} supplier artifacts, ${awardCount} award notices.`;
}

function submissionPackageVersionLabel(t: (key: string) => string, versionNumber: number) {
  return t("intentsPage.submissionEvidencePackageVersion").replace("{version}", String(versionNumber));
}

function freshnessTone(status: QualificationFreshnessResponse["status"] | undefined) {
  if (status === "current") return "border-emerald-200 bg-emerald-50 text-emerald-700";
  if (status === "stale") return "border-amber-200 bg-amber-50 text-amber-700";
  return "border-slate-200 bg-slate-50 text-slate-600";
}

function LockedFeatureState({
  message,
  title,
}: {
  message: string;
  title: string;
}) {
  return (
    <UniversalState
      className="mt-4 border-amber-200 bg-amber-50/60 p-4 shadow-none"
      code="plan_limit"
      message={message}
      title={title}
    />
  );
}

const submissionMethods: SubmissionMethod[] = [
  "external_portal",
  "email",
  "physical_delivery",
  "mixed",
  "unknown",
];

const complianceStatuses: ComplianceItemStatus[] = [...COMPLIANCE_ITEM_STATUSES];
const complianceEvidenceStatuses: ComplianceEvidenceStatus[] = [...COMPLIANCE_EVIDENCE_STATUSES];
const pursuitDecisionOptions: PursuitDecisionValue[] = [...PURSUIT_DECISIONS];
const knowledgeTypeOptions: KnowledgeItem["type"][] = [
  "workflow_note",
  "template_snippet",
  "requirement",
  "lesson",
];

type SubmissionDraft = Pick<
  SubmissionGuidance,
  | "method"
  | "portalUrl"
  | "contactEmail"
  | "requiresRegistration"
  | "requiresPhysicalDelivery"
  | "requiresAddendaAcknowledgement"
>;

interface ConfirmationDraft {
  submittedAt: string;
  method: SubmissionMethod;
  confirmationReference: string;
  confirmationNotes: string;
}

interface PursuitDecisionDraft {
  decision: PursuitDecisionValue;
  reasons: string;
  notes: string;
}

interface KnowledgeDraft {
  title: string;
  type: KnowledgeItem["type"];
  tags: string;
  body: string;
}

const defaultSubmissionDraft: SubmissionDraft = {
  method: "unknown",
  portalUrl: "",
  contactEmail: "",
  requiresRegistration: false,
  requiresPhysicalDelivery: false,
  requiresAddendaAcknowledgement: false,
};

const defaultPursuitDecisionDraft: PursuitDecisionDraft = {
  decision: "defer",
  reasons: "",
  notes: "",
};

const defaultKnowledgeDraft: KnowledgeDraft = {
  title: "",
  type: "workflow_note",
  tags: "",
  body: "",
};

const defaultArtifactDraft: ArtifactDraft = {
  title: "",
  artifactType: "w9",
  purpose: "compliance_evidence",
  expiresAt: "",
  notes: "",
  file: null,
};

const defaultQuoteDraft: QuoteDraft = {
  partnerName: "",
  contactName: "",
  contactEmail: "",
  title: "",
  description: "",
  requestedDueAt: "",
  lineItems: "",
  artifactIds: [],
};

function currentDatetimeLocal() {
  const now = new Date();
  const offsetMs = now.getTimezoneOffset() * 60_000;

  return new Date(now.getTime() - offsetMs).toISOString().slice(0, 16);
}

function toSubmissionDraft(submission: SubmissionGuidance): SubmissionDraft {
  return {
    method: submission.method,
    portalUrl: submission.portalUrl,
    contactEmail: submission.contactEmail,
    requiresRegistration: submission.requiresRegistration,
    requiresPhysicalDelivery: submission.requiresPhysicalDelivery,
    requiresAddendaAcknowledgement: submission.requiresAddendaAcknowledgement,
  };
}

function toIsoFromDatetimeLocal(value: string) {
  const date = new Date(value);

  return Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
}

function defaultSnoozeUntil() {
  const date = new Date();
  date.setHours(date.getHours() + 24);

  return date.toISOString();
}

function parseKnowledgeTags(value: string) {
  return value
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
}

function knowledgeRetrievalTraceQuery(intent: IntentDetail) {
  return [
    intent.bid.title,
    intent.bid.description,
    intent.generated.aiBidBrief,
    intent.match.explanation,
  ]
    .filter(Boolean)
    .join(" ")
    .trim()
    .slice(0, 500);
}

const pursuitLanes = [
  { key: "intent", count: "1", items: ["match", "brief"] },
  { key: "review", count: "3", items: ["risk", "questions"] },
  { key: "prepare", count: "2", items: ["documents", "pricing"] },
  { key: "submit", count: "1", items: ["confirmation"] },
] as const;

export default function IntentWorkspacePage() {
  const params = useParams();
  const router = useRouter();
  const { user, isLoading: isAuthLoading } = useAuth();
  const { t } = useLanguage();
  const mountedRef = useRef(true);
  const saveRequestRef = useRef(0);
  const [intent, setIntent] = useState<IntentDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<Error | null>(null);
  const [saveError, setSaveError] = useState<Error | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [submissionGuidance, setSubmissionGuidance] = useState<SubmissionGuidance | null>(null);
  const [submissionDraft, setSubmissionDraft] = useState<SubmissionDraft>(defaultSubmissionDraft);
  const [submissionConfirmations, setSubmissionConfirmations] = useState<SubmissionConfirmation[]>([]);
  const [submissionConfirmation, setSubmissionConfirmation] = useState<SubmissionConfirmation | null>(null);
  const [submissionEvidenceLinks, setSubmissionEvidenceLinks] = useState<SubmissionEvidenceLinks>(emptySubmissionEvidenceLinks);
  const [confirmationDraft, setConfirmationDraft] = useState<ConfirmationDraft>({
    submittedAt: currentDatetimeLocal(),
    method: "unknown",
    confirmationReference: "",
    confirmationNotes: "",
  });
  const [isSubmissionLoading, setIsSubmissionLoading] = useState(false);
  const [isSubmissionSaving, setIsSubmissionSaving] = useState(false);
  const [isConfirmationSaving, setIsConfirmationSaving] = useState(false);
  const [submissionError, setSubmissionError] = useState<Error | null>(null);
  const [submissionNotice, setSubmissionNotice] = useState("");
  const [complianceManifest, setComplianceManifest] = useState<ComplianceManifest | null>(null);
  const [isComplianceLoading, setIsComplianceLoading] = useState(false);
  const [complianceSavingItemId, setComplianceSavingItemId] = useState<string | null>(null);
  const [complianceError, setComplianceError] = useState<Error | null>(null);
  const [complianceNotice, setComplianceNotice] = useState("");
  const [pursuitDecisionBoard, setPursuitDecisionBoard] = useState<PursuitDecisionBoard | null>(null);
  const [pursuitDecisionDraft, setPursuitDecisionDraft] = useState<PursuitDecisionDraft>(defaultPursuitDecisionDraft);
  const [isPursuitDecisionLoading, setIsPursuitDecisionLoading] = useState(false);
  const [isPursuitDecisionSaving, setIsPursuitDecisionSaving] = useState(false);
  const [pursuitDecisionError, setPursuitDecisionError] = useState<Error | null>(null);
  const [pursuitDecisionNotice, setPursuitDecisionNotice] = useState("");
  const [responseWorkspace, setResponseWorkspace] = useState<ResponseWorkspace | null>(null);
  const [isResponseWorkspaceLoading, setIsResponseWorkspaceLoading] = useState(false);
  const [responseWorkspaceSavingItemId, setResponseWorkspaceSavingItemId] = useState<string | null>(null);
  const [responseWorkspaceError, setResponseWorkspaceError] = useState<Error | null>(null);
  const [responseWorkspaceNotice, setResponseWorkspaceNotice] = useState("");
  const [responseWorkspaceCommentsByItemId, setResponseWorkspaceCommentsByItemId] = useState<Record<string, ResponseWorkspaceComment[]>>({});
  const [responseWorkspaceCommentDrafts, setResponseWorkspaceCommentDrafts] = useState<Record<string, string>>({});
  const [responseWorkspaceSavingCommentItemId, setResponseWorkspaceSavingCommentItemId] = useState<string | null>(null);
  const [responsePackageWorkspace, setResponsePackageWorkspace] = useState<ResponsePackageWorkspace | null>(null);
  const [isResponsePackageSaving, setIsResponsePackageSaving] = useState(false);
  const [responsePackageExportingSnapshotId, setResponsePackageExportingSnapshotId] = useState<string | null>(null);
  const [responsePackageReviewingExportId, setResponsePackageReviewingExportId] = useState<string | null>(null);
  const [artifactVault, setArtifactVault] = useState<ArtifactVault | null>(null);
  const [artifactDraft, setArtifactDraft] = useState<ArtifactDraft>(defaultArtifactDraft);
  const [isArtifactVaultLoading, setIsArtifactVaultLoading] = useState(false);
  const [isArtifactUploading, setIsArtifactUploading] = useState(false);
  const [deletingArtifactId, setDeletingArtifactId] = useState<string | null>(null);
  const [replacingArtifactId, setReplacingArtifactId] = useState<string | null>(null);
  const [artifactVaultError, setArtifactVaultError] = useState<Error | null>(null);
  const [artifactVaultNotice, setArtifactVaultNotice] = useState("");
  const [quoteWorkspace, setQuoteWorkspace] = useState<QuoteWorkspace | null>(null);
  const [quoteDraft, setQuoteDraft] = useState<QuoteDraft>(defaultQuoteDraft);
  const [isQuoteWorkspaceLoading, setIsQuoteWorkspaceLoading] = useState(false);
  const [isQuoteSaving, setIsQuoteSaving] = useState(false);
  const [quoteSavingRequestId, setQuoteSavingRequestId] = useState<string | null>(null);
  const [quoteError, setQuoteError] = useState<Error | null>(null);
  const [quoteNotice, setQuoteNotice] = useState("");
  const [deadlineWorkspace, setDeadlineWorkspace] = useState<DeadlineWorkspace | null>(null);
  const [isDeadlineWorkspaceLoading, setIsDeadlineWorkspaceLoading] = useState(false);
  const [deadlineSavingReminderId, setDeadlineSavingReminderId] = useState<string | null>(null);
  const [deadlineError, setDeadlineError] = useState<Error | null>(null);
  const [deadlineNotice, setDeadlineNotice] = useState("");
  const [awardOutcome, setAwardOutcome] = useState<AwardOutcome | null>(null);
  const [isAwardOutcomeLoading, setIsAwardOutcomeLoading] = useState(false);
  const [isAwardOutcomeSaving, setIsAwardOutcomeSaving] = useState(false);
  const [awardOutcomeError, setAwardOutcomeError] = useState<Error | null>(null);
  const [awardOutcomeNotice, setAwardOutcomeNotice] = useState("");
  const [qualificationCitations, setQualificationCitations] = useState<QualificationCitation[]>([]);
  const [qualificationFreshness, setQualificationFreshness] = useState<QualificationFreshnessResponse | null>(null);
  const [isCitationsLoading, setIsCitationsLoading] = useState(false);
  const [isFreshnessLoading, setIsFreshnessLoading] = useState(false);
  const [isRefreshingQualification, setIsRefreshingQualification] = useState(false);
  const [qualificationRefreshError, setQualificationRefreshError] = useState<Error | null>(null);
  const [qaQuestion, setQaQuestion] = useState("");
  const [qaAnswer, setQaAnswer] = useState<QualificationQuestionResponse | null>(null);
  const [isQaLoading, setIsQaLoading] = useState(false);
  const [qaError, setQaError] = useState<Error | null>(null);
  const [knowledgeItems, setKnowledgeItems] = useState<KnowledgeItem[]>([]);
  const [knowledgeRetrievalTrace, setKnowledgeRetrievalTrace] = useState<KnowledgeRetrievalTrace | null>(null);
  const [knowledgeNotice, setKnowledgeNotice] = useState("");
  const [knowledgeError, setKnowledgeError] = useState<Error | null>(null);
  const [knowledgeDraft, setKnowledgeDraft] = useState<KnowledgeDraft>(defaultKnowledgeDraft);
  const [isKnowledgeLoading, setIsKnowledgeLoading] = useState(false);
  const [isKnowledgeSaving, setIsKnowledgeSaving] = useState(false);
  const [savingKnowledgeCoachCardId, setSavingKnowledgeCoachCardId] = useState<string | null>(null);
  const submissionGuidanceFeature = useFeature("submission_guidance");
  const complianceManifestFeature = useFeature("compliance_manifest");
  const pursuitDecisionFeature = useFeature("pursue_no_bid");
  const responseWorkspaceFeature = useFeature("response.workspace.create");
  const artifactVaultFeature = useFeature("artifact.vault.upload");
  const quoteWorkflowFeature = useFeature("quote_workflow");
  const deadlineNotificationsFeature = useFeature("deadline_notifications");
  const awardOutcomeFeature = useFeature("award.tabulation.analyze");
  const qualificationQaFeature = useFeature("bid.brief.full.generate");
  const knowledgeStationFeature = useFeature("knowledge_station");

  const intentId = user ? typeof params?.id === "string" ? params.id : Array.isArray(params?.id) ? params.id[0] : "" : "";
  const responseWorkspaceAssigneeOptions = useMemo(() => {
    const options = new Map<string, string>();

    if (user) {
      options.set(user.id, user.displayName || user.email || user.id);
    }

    for (const item of responseWorkspace?.items ?? []) {
      if (item.assignedUserId && item.assignedUser) {
        options.set(
          item.assignedUserId,
          item.assignedUser.displayName || item.assignedUser.email || item.assignedUser.userId,
        );
      }
    }

    return [...options.entries()].map(([userId, label]) => ({ userId, label }));
  }, [responseWorkspace?.items, user]);

  useEffect(() => {
    mountedRef.current = true;
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setIntent(null);
      setLoadError(null);
      setIsLoading(true);

      if (!intentId) {
        setIsLoading(false);
        return;
      }

      fetchIntent(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setIntent(response.intent);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setLoadError(err instanceof Error ? err : new Error("Failed to load intent"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsLoading(false);
        });
    });

    return () => {
      cancelled = true;
      mountedRef.current = false;
    };
  }, [intentId]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setQualificationCitations([]);
      setQualificationFreshness(null);
      setQualificationRefreshError(null);
      setQaAnswer(null);
      setQaError(null);

      if (!intentId) {
        setIsCitationsLoading(false);
        setIsFreshnessLoading(false);
        return;
      }

      setIsCitationsLoading(true);
      setIsFreshnessLoading(true);

      fetchQualificationFreshness(intentId)
        .then(async (freshnessResponse) => {
          const citationsResponse = await fetchQualificationCitations(intentId);
          if (cancelled || !mountedRef.current) return;
          setQualificationCitations(citationsResponse.citations);
          setQualificationFreshness(freshnessResponse);
        })
        .catch(() => {
          if (cancelled || !mountedRef.current) return;
          setQualificationCitations([]);
          setQualificationFreshness(null);
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsCitationsLoading(false);
          setIsFreshnessLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setSubmissionGuidance(null);
      setSubmissionDraft(defaultSubmissionDraft);
      setSubmissionConfirmations([]);
      setSubmissionConfirmation(null);
      setSubmissionEvidenceLinks(emptySubmissionEvidenceLinks);
      setSubmissionNotice("");
      setSubmissionError(null);

      if (!intentId || !submissionGuidanceFeature.enabled) {
        setIsSubmissionLoading(false);
        return;
      }

      setIsSubmissionLoading(true);

      fetchSubmissionGuidance(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;

          setSubmissionGuidance(response.submission);
          setSubmissionConfirmations(response.confirmations);
          setSubmissionConfirmation(response.confirmations[response.confirmations.length - 1] ?? null);
          setSubmissionEvidenceLinks(response.evidenceLinks);
          setSubmissionDraft(toSubmissionDraft(response.submission));
          setConfirmationDraft({
            submittedAt: currentDatetimeLocal(),
            method: response.submission.method,
            confirmationReference: "",
            confirmationNotes: "",
          });
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setSubmissionError(err instanceof Error ? err : new Error("Failed to load submission guidance"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsSubmissionLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, submissionGuidanceFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setComplianceManifest(null);
      setComplianceNotice("");
      setComplianceError(null);

      if (!intentId || !complianceManifestFeature.enabled) {
        setIsComplianceLoading(false);
        return;
      }

      setIsComplianceLoading(true);

      fetchComplianceManifest(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setComplianceManifest(response.manifest);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setComplianceError(err instanceof Error ? err : new Error("Failed to load compliance manifest"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsComplianceLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, complianceManifestFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setPursuitDecisionBoard(null);
      setPursuitDecisionDraft(defaultPursuitDecisionDraft);
      setPursuitDecisionNotice("");
      setPursuitDecisionError(null);

      if (!intentId || !pursuitDecisionFeature.enabled) {
        setIsPursuitDecisionLoading(false);
        return;
      }

      setIsPursuitDecisionLoading(true);

      fetchPursuitDecisionBoard(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;

          setPursuitDecisionBoard(response.decisionBoard);
          if (response.decisionBoard.currentDecision) {
            setPursuitDecisionDraft({
              decision: response.decisionBoard.currentDecision.decision,
              reasons: response.decisionBoard.currentDecision.reasons.join("\n"),
              notes: response.decisionBoard.currentDecision.notes,
            });
          }
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setPursuitDecisionError(err instanceof Error ? err : new Error("Failed to load pursuit decision"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsPursuitDecisionLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, pursuitDecisionFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setResponseWorkspace(null);
      setResponsePackageWorkspace(null);
      setResponseWorkspaceNotice("");
      setResponseWorkspaceError(null);
      setResponseWorkspaceCommentsByItemId({});
      setResponseWorkspaceCommentDrafts({});

      if (!intentId || !responseWorkspaceFeature.enabled) {
        setIsResponseWorkspaceLoading(false);
        return;
      }

      setIsResponseWorkspaceLoading(true);

      fetchResponseWorkspace(intentId)
        .then(async (response) => {
          if (cancelled || !mountedRef.current) return;
          setResponseWorkspace(response.workspace);
          const [commentPairs, packageResponse] = await Promise.all([
            Promise.all(response.workspace.items.map(async (item) => {
              const result = await fetchResponseWorkspaceComments(intentId, item.id);
              return [item.id, result.comments] as const;
            })),
            fetchResponsePackageWorkspace(intentId),
          ]);
          if (cancelled || !mountedRef.current) return;
          setResponseWorkspaceCommentsByItemId(Object.fromEntries(commentPairs));
          setResponsePackageWorkspace(packageResponse.packageWorkspace);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to load response workspace"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsResponseWorkspaceLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, responseWorkspaceFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setArtifactVault(null);
      setArtifactVaultNotice("");
      setArtifactVaultError(null);
      setArtifactDraft(defaultArtifactDraft);

      if (!intentId || !artifactVaultFeature.enabled) {
        setIsArtifactVaultLoading(false);
        return;
      }

      setIsArtifactVaultLoading(true);

      fetchArtifactVault(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setArtifactVault(response.vault);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setArtifactVaultError(err instanceof Error ? err : new Error("Failed to load artifact vault"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsArtifactVaultLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, artifactVaultFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setQuoteWorkspace(null);
      setQuoteDraft(defaultQuoteDraft);
      setQuoteNotice("");
      setQuoteError(null);

      if (!intentId || !quoteWorkflowFeature.enabled) {
        setIsQuoteWorkspaceLoading(false);
        return;
      }

      setIsQuoteWorkspaceLoading(true);

      fetchQuoteWorkspace(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setQuoteWorkspace(response.workspace);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setQuoteError(err instanceof Error ? err : new Error("Failed to load quote workspace"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsQuoteWorkspaceLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, quoteWorkflowFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setDeadlineWorkspace(null);
      setDeadlineNotice("");
      setDeadlineError(null);

      if (!intentId || !deadlineNotificationsFeature.enabled) {
        setIsDeadlineWorkspaceLoading(false);
        return;
      }

      setIsDeadlineWorkspaceLoading(true);

      fetchDeadlineWorkspace(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setDeadlineWorkspace(response.workspace);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setDeadlineError(err instanceof Error ? err : new Error("Failed to load deadline reminders"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsDeadlineWorkspaceLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, deadlineNotificationsFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setAwardOutcome(null);
      setAwardOutcomeNotice("");
      setAwardOutcomeError(null);

      if (!intentId || !awardOutcomeFeature.enabled) {
        setIsAwardOutcomeLoading(false);
        return;
      }

      setIsAwardOutcomeLoading(true);

      fetchAwardOutcome(intentId)
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setAwardOutcome(response.outcome);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setAwardOutcomeError(err instanceof Error ? err : new Error("Failed to load award outcome"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsAwardOutcomeLoading(false);
        });
    });

    return () => {
      cancelled = true;
    };
  }, [intentId, awardOutcomeFeature.enabled]);

  useEffect(() => {
    let cancelled = false;

    queueMicrotask(() => {
      if (cancelled || !mountedRef.current) return;

      setKnowledgeItems([]);
      setKnowledgeRetrievalTrace(null);
      setKnowledgeNotice("");
      setKnowledgeError(null);
      setKnowledgeDraft(defaultKnowledgeDraft);

      if (!intent || !knowledgeStationFeature.enabled) {
        setIsKnowledgeLoading(false);
        return;
      }

      setIsKnowledgeLoading(true);

      fetchKnowledgeItems({ intentId: intent.id, bidId: intent.bid.id, limit: 10 })
        .then((response) => {
          if (cancelled || !mountedRef.current) return;
          setKnowledgeItems(response.items);
        })
        .catch((err) => {
          if (cancelled || !mountedRef.current) return;
          setKnowledgeError(err instanceof Error ? err : new Error("Failed to load knowledge items"));
        })
        .finally(() => {
          if (cancelled || !mountedRef.current) return;
          setIsKnowledgeLoading(false);
        });

      const traceQuery = knowledgeRetrievalTraceQuery(intent);

      if (traceQuery) {
        fetchKnowledgeItems({ q: traceQuery, limit: 10, includeRetrievalTrace: true })
          .then((response) => {
            if (cancelled || !mountedRef.current) return;
            setKnowledgeRetrievalTrace(response.retrievalTrace ?? null);
          })
          .catch(() => {
            if (cancelled || !mountedRef.current) return;
            setKnowledgeRetrievalTrace(null);
          });
      }
    });

    return () => {
      cancelled = true;
    };
  }, [intent, knowledgeStationFeature.enabled]);

  const matchComponents = useMemo(() => {
    if (!intent) return [];
    return Object.entries(intent.match.components);
  }, [intent]);

  const workflowCoachCards = useMemo<WorkflowCoachCard[]>(() => {
    if (!intent) return [];
    return generateWorkflowCoachCards(intent);
  }, [intent]);

  const quoteComparisonSummary = quoteWorkspace?.summary.comparison ?? null;
  const quoteComparisonMetrics = [
    ["Low", quoteComparisonSummary?.lowAmountCents ?? null],
    ["Median", quoteComparisonSummary?.medianAmountCents ?? null],
    ["High", quoteComparisonSummary?.highAmountCents ?? null],
    ["Spread", quoteComparisonSummary?.spreadAmountCents ?? null],
  ] as const;
  const learningSummary = awardOutcome?.learningSummary ?? null;
  const evidenceAutoLinkSummary = submissionEvidenceAutoLinkSummary(submissionEvidenceLinks);

  const handleAskEvidenceQuestion = async () => {
    if (!intent || !qualificationQaFeature.enabled || isQaLoading) return;

    const question = qaQuestion.trim();
    if (!question) {
      setQaError(new Error("Question is required"));
      return;
    }

    setIsQaLoading(true);
    setQaAnswer(null);
    setQaError(null);

    try {
      const response = await postQualificationQuestion(intent.id, { question });
      if (!mountedRef.current) return;

      setQaAnswer(response);
      setQaQuestion(response.question);
    } catch (err) {
      if (!mountedRef.current) return;
      setQaError(err instanceof Error ? err : new Error("Failed to answer question"));
    } finally {
      if (mountedRef.current) {
        setIsQaLoading(false);
      }
    }
  };

  const handleRefreshQualificationEvidence = async () => {
    if (!intent || isRefreshingQualification) return;

    setIsRefreshingQualification(true);
    setQualificationRefreshError(null);

    try {
      const response = await refreshQualificationEvidence(intent.id);
      if (!mountedRef.current) return;

      setIntent(response.intent);
      setQualificationCitations(response.citations.citations);
      setQualificationFreshness(response.freshness);
      setQaAnswer(null);
      setQaError(null);
    } catch (err) {
      if (!mountedRef.current) return;
      setQualificationRefreshError(err instanceof Error ? err : new Error("Failed to refresh qualification evidence"));
    } finally {
      if (mountedRef.current) {
        setIsRefreshingQualification(false);
      }
    }
  };

  const handleStatusChange = async (status: IntentStatus | null) => {
    if (!intent || !status || status === intent.status || isSaving) return;

    const nextStatus = status;
    const previousIntent = intent;
    const requestId = saveRequestRef.current + 1;
    saveRequestRef.current = requestId;

    setIntent({ ...intent, status: nextStatus });
    setIsSaving(true);
    setIsSaved(false);
    setSaveError(null);

    try {
      const response = await updateIntentStatus(intent.id, nextStatus);
      if (!mountedRef.current || saveRequestRef.current !== requestId) return;

      setIntent(response.intent);
      setIsSaved(true);
    } catch (err) {
      if (!mountedRef.current || saveRequestRef.current !== requestId) return;

      setIntent(previousIntent);
      setSaveError(err instanceof Error ? err : new Error("Failed to save intent status"));
    } finally {
      if (mountedRef.current && saveRequestRef.current === requestId) {
        setIsSaving(false);
      }
    }
  };

  const handleSaveSubmissionGuidance = async () => {
    if (!intent || !submissionGuidanceFeature.enabled || isSubmissionSaving) return;

    setIsSubmissionSaving(true);
    setSubmissionNotice("");
    setSubmissionError(null);

    try {
      const response = await updateSubmissionGuidance(intent.id, submissionDraft);
      if (!mountedRef.current) return;

      setSubmissionGuidance(response.submission);
      setSubmissionConfirmations(response.confirmations);
      setSubmissionConfirmation(response.confirmations[response.confirmations.length - 1] ?? null);
      setSubmissionEvidenceLinks(response.evidenceLinks);
      setSubmissionDraft(toSubmissionDraft(response.submission));
      setConfirmationDraft((current) => ({ ...current, method: response.submission.method }));
      setSubmissionNotice(t("intentsPage.submissionGuidanceSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setSubmissionError(err instanceof Error ? err : new Error("Failed to save submission guidance"));
    } finally {
      if (mountedRef.current) {
        setIsSubmissionSaving(false);
      }
    }
  };

  const handleConfirmSubmission = async () => {
    if (!intent || !submissionGuidanceFeature.enabled || isConfirmationSaving) return;

    setIsConfirmationSaving(true);
    setSubmissionNotice("");
    setSubmissionError(null);

    try {
      const response = await confirmSubmission(intent.id, {
        submittedAt: toIsoFromDatetimeLocal(confirmationDraft.submittedAt),
        method: confirmationDraft.method,
        confirmationReference: confirmationDraft.confirmationReference.trim(),
        confirmationNotes: confirmationDraft.confirmationNotes.trim(),
      });
      if (!mountedRef.current) return;

      setSubmissionConfirmation(response.confirmation);
      setSubmissionGuidance(response.submission);
      setSubmissionConfirmations(response.confirmations);
      setSubmissionEvidenceLinks(response.evidenceLinks);
      setConfirmationDraft({
        submittedAt: currentDatetimeLocal(),
        method: response.confirmation.method,
        confirmationReference: "",
        confirmationNotes: "",
      });
      setSubmissionNotice(t("intentsPage.submissionConfirmationSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setSubmissionError(err instanceof Error ? err : new Error("Failed to confirm submission"));
    } finally {
      if (mountedRef.current) {
        setIsConfirmationSaving(false);
      }
    }
  };

  function updateLocalComplianceItem(
    itemId: string,
    patch: Partial<Pick<ComplianceManifestItem, "status" | "evidenceStatus" | "notes">>,
  ) {
    setComplianceManifest((current) => current
      ? {
          ...current,
          items: current.items.map((item) => (item.id === itemId ? { ...item, ...patch } : item)),
        }
      : current);
  }

  const handleComplianceItemUpdate = async (
    item: ComplianceManifestItem,
    patch: Partial<Pick<ComplianceManifestItem, "status" | "evidenceStatus" | "notes">>,
  ) => {
    if (!intent || !complianceManifestFeature.enabled || complianceSavingItemId) return;

    setComplianceSavingItemId(item.id);
    setComplianceNotice("");
    setComplianceError(null);

    try {
      const response = await updateComplianceManifestItem(intent.id, {
        itemId: item.id,
        ...patch,
      });
      if (!mountedRef.current) return;

      setComplianceManifest(response.manifest);
      setComplianceNotice(t("intentsPage.complianceManifestSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setComplianceError(err instanceof Error ? err : new Error("Failed to save compliance manifest"));
    } finally {
      if (mountedRef.current) {
        setComplianceSavingItemId(null);
      }
    }
  };

  const handleSavePursuitDecision = async () => {
    if (!intent || !pursuitDecisionFeature.enabled || isPursuitDecisionSaving) return;

    setIsPursuitDecisionSaving(true);
    setPursuitDecisionNotice("");
    setPursuitDecisionError(null);

    try {
      const response = await updatePursuitDecision(intent.id, {
        decision: pursuitDecisionDraft.decision,
        reasons: pursuitDecisionDraft.reasons
          .split("\n")
          .map((reason) => reason.trim())
          .filter(Boolean),
        notes: pursuitDecisionDraft.notes.trim(),
      });
      if (!mountedRef.current) return;

      setPursuitDecisionBoard(response.decisionBoard);
      setPursuitDecisionNotice(t("intentsPage.pursuitDecisionSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setPursuitDecisionError(err instanceof Error ? err : new Error("Failed to save pursuit decision"));
    } finally {
      if (mountedRef.current) {
        setIsPursuitDecisionSaving(false);
      }
    }
  };

  function updateLocalResponseWorkspaceItem(
    itemId: string,
    patch: Partial<Pick<ResponseWorkspaceItem, "status" | "notes" | "title" | "dueAt" | "assignedUserId" | "assignedUser">>,
  ) {
    setResponseWorkspace((current) => current
      ? {
          ...current,
          items: current.items.map((item) => (item.id === itemId ? { ...item, ...patch } : item)),
        }
      : current);
  }

  async function refreshResponsePackageWorkspace(intentId: string) {
    const packageResponse = await fetchResponsePackageWorkspace(intentId);
    if (!mountedRef.current) return;
    setResponsePackageWorkspace(packageResponse.packageWorkspace);
  }

  async function refreshResponseWorkspace(intentId: string) {
    const workspaceResponse = await fetchResponseWorkspace(intentId);
    if (!mountedRef.current) return;
    setResponseWorkspace(workspaceResponse.workspace);
  }

  async function refreshQuoteWorkspace(intentId: string) {
    const quoteResponse = await fetchQuoteWorkspace(intentId);
    if (!mountedRef.current) return;
    setQuoteWorkspace(quoteResponse.workspace);
  }

  const handleResponseWorkspaceItemUpdate = async (
    item: ResponseWorkspaceItem,
    patch: Partial<Pick<ResponseWorkspaceItem, "status" | "notes" | "title" | "dueAt" | "assignedUserId">>,
  ) => {
    if (!intent || !responseWorkspaceFeature.enabled || responseWorkspaceSavingItemId) return;

    setResponseWorkspaceSavingItemId(item.id);
    setResponseWorkspaceNotice("");
    setResponseWorkspaceError(null);

    try {
      const response = await updateResponseWorkspaceItem(intent.id, {
        itemId: item.id,
        ...patch,
      });
      if (!mountedRef.current) return;

      setResponseWorkspace(response.workspace);
      await refreshResponsePackageWorkspace(intent.id);
      setResponseWorkspaceNotice(t("intentsPage.responseWorkspaceSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to save response workspace"));
    } finally {
      if (mountedRef.current) {
        setResponseWorkspaceSavingItemId(null);
      }
    }
  };

  const handleSaveResponseWorkspaceLinkedArtifacts = async (
    item: ResponseWorkspaceItem,
    linkedArtifactIds: string[],
  ) => {
    if (!intent || !responseWorkspaceFeature.enabled || responseWorkspaceSavingItemId) return;

    setResponseWorkspaceSavingItemId(item.id);
    setResponseWorkspaceNotice("");
    setResponseWorkspaceError(null);

    try {
      const response = await updateResponseWorkspaceItemArtifactLinks(intent.id, item.id, linkedArtifactIds);
      if (!mountedRef.current) return;

      setResponseWorkspace(response.workspace);
      await refreshResponsePackageWorkspace(intent.id);
      setResponseWorkspaceNotice(t("intentsPage.responseWorkspaceSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to save response workspace"));
    } finally {
      if (mountedRef.current) {
        setResponseWorkspaceSavingItemId(null);
      }
    }
  };

  const handleCreateResponseWorkspaceComment = async (item: ResponseWorkspaceItem) => {
    if (!intent || !responseWorkspaceFeature.enabled || responseWorkspaceSavingCommentItemId) return;
    const body = (responseWorkspaceCommentDrafts[item.id] ?? "").trim();
    if (!body) return;

    setResponseWorkspaceSavingCommentItemId(item.id);
    setResponseWorkspaceNotice("");
    setResponseWorkspaceError(null);

    try {
      const response = await createResponseWorkspaceComment(intent.id, {
        itemId: item.id,
        body,
      });
      if (!mountedRef.current) return;

      setResponseWorkspaceCommentsByItemId((current) => ({
        ...current,
        [item.id]: [...(current[item.id] ?? []), response.comment],
      }));
      setResponseWorkspaceCommentDrafts((current) => ({ ...current, [item.id]: "" }));
      setResponseWorkspaceNotice(t("intentsPage.responseWorkspaceCommentSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to save response workspace comment"));
    } finally {
      if (mountedRef.current) {
        setResponseWorkspaceSavingCommentItemId(null);
      }
    }
  };

  const handleCreateResponsePackageSnapshot = async () => {
    if (!intent || !responseWorkspaceFeature.enabled || isResponsePackageSaving) return;

    setIsResponsePackageSaving(true);
    setResponseWorkspaceNotice("");
    setResponseWorkspaceError(null);

    try {
      const response = await createResponsePackageSnapshot(intent.id, {});
      if (!mountedRef.current) return;

      setResponsePackageWorkspace(response.packageWorkspace);
      setResponseWorkspaceNotice(t("intentsPage.responsePackageSnapshotCreated"));
    } catch (err) {
      if (!mountedRef.current) return;
      setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to create response package snapshot"));
    } finally {
      if (mountedRef.current) {
        setIsResponsePackageSaving(false);
      }
    }
  };

  const handleCreateResponsePackageExport = async (snapshotId: string, format: ResponsePackageExportFormat) => {
    if (!intent || !responseWorkspaceFeature.enabled || responsePackageExportingSnapshotId) return;

    setResponsePackageExportingSnapshotId(snapshotId);
    setResponseWorkspaceNotice("");
    setResponseWorkspaceError(null);

    try {
      const response = await createResponsePackageExport(intent.id, { snapshotId, format });
      if (!mountedRef.current) return;

      await refreshResponsePackageWorkspace(intent.id);
      setResponseWorkspaceNotice(t("intentsPage.responsePackageExportCreated"));
      window.open(response.exportRecord.downloadUrl, "_blank", "noopener,noreferrer");
    } catch (err) {
      if (!mountedRef.current) return;
      setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to export response package"));
    } finally {
      if (mountedRef.current) {
        setResponsePackageExportingSnapshotId(null);
      }
    }
  };

  const handleReviewResponsePackageExport = async (
    exportId: string,
    reviewStatus: ResponsePackageExportReviewStatus,
    reviewNotes: string,
  ) => {
    if (!intent || !responseWorkspaceFeature.enabled || responsePackageReviewingExportId) return;

    setResponsePackageReviewingExportId(exportId);
    setResponseWorkspaceNotice("");
    setResponseWorkspaceError(null);

    try {
      await updateResponsePackageExportReview(intent.id, exportId, {
        reviewStatus,
        reviewNotes,
      });
      if (!mountedRef.current) return;

      await refreshResponsePackageWorkspace(intent.id);
      setResponseWorkspaceNotice(t("intentsPage.responsePackageReviewSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setResponseWorkspaceError(err instanceof Error ? err : new Error("Failed to review response package"));
    } finally {
      if (mountedRef.current) {
        setResponsePackageReviewingExportId(null);
      }
    }
  };

  const handleUploadArtifact = async () => {
    if (!intent || !artifactVaultFeature.enabled || isArtifactUploading) return;

    if (!artifactDraft.file) {
      setArtifactVaultError(new Error("Artifact file is required"));
      return;
    }

    setIsArtifactUploading(true);
    setArtifactVaultNotice("");
    setArtifactVaultError(null);

    try {
      const response = await uploadSupplierArtifact(intent.id, {
        title: artifactDraft.title,
        artifactType: artifactDraft.artifactType,
        purpose: artifactDraft.purpose,
        expiresAt: artifactDraft.expiresAt || null,
        notes: artifactDraft.notes,
        file: artifactDraft.file,
      });
      if (!mountedRef.current) return;

      setArtifactVault(response.vault);
      setArtifactDraft(defaultArtifactDraft);
      setArtifactVaultNotice(t("intentsPage.artifactUploadSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setArtifactVaultError(err instanceof Error ? err : new Error("Failed to upload artifact"));
    } finally {
      if (mountedRef.current) {
        setIsArtifactUploading(false);
      }
    }
  };

  const handleDeleteSupplierArtifact = async (artifactId: string) => {
    if (!intent || !artifactVaultFeature.enabled || deletingArtifactId) return;

    setDeletingArtifactId(artifactId);
    setArtifactVaultNotice("");
    setArtifactVaultError(null);

    try {
      const response = await deleteSupplierArtifact(intent.id, artifactId);
      if (!mountedRef.current) return;

      setArtifactVault(response.vault);
      setQuoteDraft((current) => ({
        ...current,
        artifactIds: current.artifactIds.filter((id) => id !== artifactId),
      }));

      await Promise.all([
        responseWorkspaceFeature.enabled
          ? Promise.all([
              refreshResponseWorkspace(intent.id),
              refreshResponsePackageWorkspace(intent.id),
            ])
          : Promise.resolve(),
        quoteWorkflowFeature.enabled ? refreshQuoteWorkspace(intent.id) : Promise.resolve(),
      ]);
      if (!mountedRef.current) return;

      setArtifactVaultNotice(t("intentsPage.artifactDeleted"));
    } catch (err) {
      if (!mountedRef.current) return;
      setArtifactVaultError(err instanceof Error ? err : new Error("Failed to delete artifact"));
    } finally {
      if (mountedRef.current) {
        setDeletingArtifactId(null);
      }
    }
  };

  const handleReplaceSupplierArtifact = async (
    artifactId: string,
    file: File,
    replacementReason: string,
  ) => {
    if (!intent || !artifactVaultFeature.enabled || replacingArtifactId) return;

    setReplacingArtifactId(artifactId);
    setArtifactVaultNotice("");
    setArtifactVaultError(null);

    try {
      const response = await replaceSupplierArtifact(intent.id, artifactId, {
        file,
        replacementReason,
      });
      if (!mountedRef.current) return;

      setArtifactVault(response.vault);

      await Promise.all([
        responseWorkspaceFeature.enabled
          ? Promise.all([
              refreshResponseWorkspace(intent.id),
              refreshResponsePackageWorkspace(intent.id),
            ])
          : Promise.resolve(),
        quoteWorkflowFeature.enabled ? refreshQuoteWorkspace(intent.id) : Promise.resolve(),
      ]);
      if (!mountedRef.current) return;

      setArtifactVaultNotice(t("intentsPage.artifactReplaced"));
    } catch (err) {
      if (!mountedRef.current) return;
      setArtifactVaultError(err instanceof Error ? err : new Error("Failed to replace artifact"));
    } finally {
      if (mountedRef.current) {
        setReplacingArtifactId(null);
      }
    }
  };

  const handleCreateQuoteRequest = async () => {
    if (!intent || !quoteWorkflowFeature.enabled || isQuoteSaving) return;

    setIsQuoteSaving(true);
    setQuoteNotice("");
    setQuoteError(null);

    try {
      const response = await createQuoteRequestDraft(intent.id, {
        partnerName: quoteDraft.partnerName,
        contactName: quoteDraft.contactName,
        contactEmail: quoteDraft.contactEmail,
        title: quoteDraft.title,
        description: quoteDraft.description,
        requestedDueAt: quoteDraft.requestedDueAt || null,
        lineItems: quoteDraft.lineItems,
        artifactIds: quoteDraft.artifactIds,
      });
      if (!mountedRef.current) return;

      setQuoteWorkspace(response.workspace);
      setQuoteDraft(defaultQuoteDraft);
      setQuoteNotice(t("intentsPage.quoteRequestSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setQuoteError(err instanceof Error ? err : new Error("Failed to save quote request"));
    } finally {
      if (mountedRef.current) setIsQuoteSaving(false);
    }
  };

  const handleQuoteRequestUpdate = async (
    request: QuoteRequest,
    patch: {
      status?: QuoteRequestStatus;
      quotedAmountCents?: number | null;
      responseNotes?: string;
    },
  ) => {
    if (!intent || !quoteWorkflowFeature.enabled || quoteSavingRequestId) return;

    setQuoteSavingRequestId(request.id);
    setQuoteNotice("");
    setQuoteError(null);

    try {
      const response = await updateQuoteRequestDraft(intent.id, {
        requestId: request.id,
        ...patch,
      });
      if (!mountedRef.current) return;

      setQuoteWorkspace(response.workspace);
      setQuoteNotice(t("intentsPage.quoteRequestUpdated"));
    } catch (err) {
      if (!mountedRef.current) return;
      setQuoteError(err instanceof Error ? err : new Error("Failed to update quote request"));
    } finally {
      if (mountedRef.current) setQuoteSavingRequestId(null);
    }
  };

  const handleDeadlineReminderUpdate = async (
    reminder: DeadlineReminder,
    action: "acknowledge" | "snooze",
  ) => {
    if (!intent || !deadlineNotificationsFeature.enabled || deadlineSavingReminderId) return;

    setDeadlineSavingReminderId(reminder.id);
    setDeadlineNotice("");
    setDeadlineError(null);

    try {
      const response = await updateDeadlineReminder(intent.id, {
        reminderId: reminder.id,
        action,
        snoozedUntil: action === "snooze" ? defaultSnoozeUntil() : undefined,
      });
      if (!mountedRef.current) return;

      setDeadlineWorkspace(response.workspace);
      setDeadlineNotice(
        action === "snooze"
          ? t("intentsPage.deadlineReminderSnoozed")
          : t("intentsPage.deadlineReminderAcknowledged"),
      );
    } catch (err) {
      if (!mountedRef.current) return;
      setDeadlineError(err instanceof Error ? err : new Error("Failed to update deadline reminder"));
    } finally {
      if (mountedRef.current) setDeadlineSavingReminderId(null);
    }
  };

  const handleAwardOutcomeUpdate = async (patch: UpdateAwardOutcomeInput) => {
    if (!intent || !awardOutcomeFeature.enabled || isAwardOutcomeSaving) return;

    setIsAwardOutcomeSaving(true);
    setAwardOutcomeNotice("");
    setAwardOutcomeError(null);

    try {
      const response = await updateAwardOutcome(intent.id, patch);
      if (!mountedRef.current) return;

      setAwardOutcome(response.outcome);
      setAwardOutcomeNotice(t("intentsPage.awardOutcomeSaved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setAwardOutcomeError(err instanceof Error ? err : new Error("Failed to save award outcome"));
    } finally {
      if (mountedRef.current) setIsAwardOutcomeSaving(false);
    }
  };

  const prependKnowledgeItem = (item: KnowledgeItem) => {
    setKnowledgeItems((current) => [item, ...current.filter((currentItem) => currentItem.id !== item.id)].slice(0, 10));
  };

  const handleSaveCoachKnowledge = async (card: WorkflowCoachCard) => {
    if (!intent || !knowledgeStationFeature.enabled || isKnowledgeSaving) return;

    setIsKnowledgeSaving(true);
    setSavingKnowledgeCoachCardId(card.id);
    setKnowledgeNotice("");
    setKnowledgeError(null);

    try {
      const response = await createKnowledgeItem({
        title: card.title,
        body: `${card.guidance}\n\n${card.suggestedAction}`,
        type: "workflow_note",
        tags: [card.category, card.severity],
        sourceKind: "generated_coach",
        sourceIntentId: intent.id,
        sourceBidId: intent.bid.id,
        sourceUrl: card.href ?? intent.bid.sourceUrl,
      });
      if (!mountedRef.current) return;

      prependKnowledgeItem(response.item);
      setKnowledgeNotice(t("knowledge.saved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setKnowledgeError(err instanceof Error ? err : new Error("Failed to save knowledge item"));
    } finally {
      if (mountedRef.current) {
        setIsKnowledgeSaving(false);
        setSavingKnowledgeCoachCardId(null);
      }
    }
  };

  const handleCreateKnowledgeItem = async () => {
    if (!intent || !knowledgeStationFeature.enabled || isKnowledgeSaving) return;

    const title = knowledgeDraft.title.trim();
    const body = knowledgeDraft.body.trim();

    if (!title || !body) {
      setKnowledgeError(new Error("Knowledge title and body are required"));
      return;
    }

    setIsKnowledgeSaving(true);
    setKnowledgeNotice("");
    setKnowledgeError(null);

    try {
      const response = await createKnowledgeItem({
        title,
        body,
        type: knowledgeDraft.type,
        tags: parseKnowledgeTags(knowledgeDraft.tags),
        sourceKind: "manual",
        sourceIntentId: intent.id,
        sourceBidId: intent.bid.id,
        sourceUrl: intent.bid.sourceUrl,
      });
      if (!mountedRef.current) return;

      prependKnowledgeItem(response.item);
      setKnowledgeDraft(defaultKnowledgeDraft);
      setKnowledgeNotice(t("knowledge.saved"));
    } catch (err) {
      if (!mountedRef.current) return;
      setKnowledgeError(err instanceof Error ? err : new Error("Failed to save knowledge item"));
    } finally {
      if (mountedRef.current) {
        setIsKnowledgeSaving(false);
      }
    }
  };

  if (isAuthLoading) {
    return (
      <div className="max-w-5xl mx-auto flex flex-col gap-6 pb-16 pt-4">
        <Skeleton className="h-9 w-32" />
        <div className="space-y-3">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-5 w-2/3" />
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthRequiredState />;
  }

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto flex flex-col gap-6 pb-16 pt-4">
        <Skeleton className="h-9 w-32" />
        <div className="space-y-3">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-5 w-2/3" />
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, index) => (
            <Card key={index} className="border-slate-200 shadow-sm rounded-xl bg-white">
              <CardHeader>
                <Skeleton className="h-5 w-40" />
              </CardHeader>
              <CardContent className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (loadError || !intent) {
    return (
      <div className="max-w-4xl mx-auto pt-4">
        <UniversalState
          actions={[{ label: t("detail.backToResults"), onClick: () => router.back(), variant: "secondary" }]}
          className="bg-white"
          code="error"
          message={t("intentsPage.detailErrorDescription")}
          title={t("intentsPage.errorTitle")}
        />
      </div>
    );
  }

  const qaAiRun = qaAnswer?.aiRun;
  const canViewKnowledgeRetrievalTrace =
    knowledgeStationFeature.enabled || user.role === "admin" || user.role === "operator";

  return (
    <div className="winbids-detail-workspace prototypeWorkspace">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="-ml-3 w-fit text-slate-500 hover:text-slate-900 font-medium"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> {t("intentsPage.backToIntents")}
        </Button>
        <Link
          href={intent.bid.sourceUrl}
          target="_blank"
          rel="noreferrer"
          className={buttonVariants({
            variant: "outline",
            className: "w-fit border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg",
          })}
        >
          <ExternalLink className="mr-2 h-4 w-4" /> {t("detail.viewSource")}
        </Link>
      </div>

      <section className="winbids-hero-panel rounded-lg border border-slate-200 bg-white p-5 shadow-sm md:p-6">
        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div className="min-w-0">
            <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
              {t("intentsPage.prototypeKicker")}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="rounded-md border-slate-200 bg-slate-50 text-slate-600">
                {t(`intentsPage.statuses.${intent.status}`)}
              </Badge>
              <Badge variant="outline" className={`rounded-md ${scoreTone(intent.match.score)}`}>
                {intent.match.score}% {t("intentsPage.matchSnapshot")}
              </Badge>
              <span className="flex min-w-0 items-center gap-1.5 text-sm font-medium text-slate-500">
                <Building2 size={14} className="shrink-0 text-slate-400" />
                <span className="truncate">{intent.bid.issuerName}</span>
              </span>
            </div>
            <h1 className="mt-3 break-words text-3xl font-black leading-tight tracking-normal text-slate-950 md:text-5xl">
              {intent.bid.title}
            </h1>
            <p className="mt-4 max-w-3xl text-base leading-7 text-slate-600">
              {t("intentsPage.prototypeDescription")}
            </p>
            <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-500">{t("intentsPage.status")}</span>
                <Select
                  value={intent.status}
                  onValueChange={(value) => void handleStatusChange(value)}
                  disabled={isSaving}
                >
                  <SelectTrigger className="h-9 min-w-56 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                    {INTENT_STATUSES.map((status) => (
                      <SelectItem key={status} value={status}>
                        {t(`intentsPage.statuses.${status}`)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <p className="min-h-5 text-sm font-medium text-slate-500">
                {isSaving
                  ? t("intentsPage.savingStatus")
                  : isSaved
                    ? t("intentsPage.saveStatus")
                    : saveError
                      ? t("intentsPage.saveError")
                      : ""}
              </p>
            </div>
          </div>

          <div className={`rounded-lg border p-5 ${scoreTone(intent.match.score)}`}>
            <Gauge size={22} aria-hidden="true" />
            <p className="mt-4 text-xs font-black uppercase">{t("intentsPage.matchSnapshot")}</p>
            <p className="mt-2 text-5xl font-black leading-none">{intent.match.score}%</p>
            <p className="mt-2 text-sm font-bold">{t(`intentsPage.confidence.${intent.match.confidence}`)}</p>
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-[minmax(0,1.35fr)_minmax(320px,0.65fr)]">
        <article className="winbids-panel rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
                {t("intentsPage.workspaceKicker")}
              </p>
              <h2 className="mt-1 text-2xl font-black text-slate-950">{t("intentsPage.brief")}</h2>
            </div>
            <span className="w-fit rounded-full border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-black text-slate-500">
              {t("intentsPage.lowRiskPursuit")}
            </span>
          </div>
          <p className="mt-5 whitespace-pre-wrap break-words text-sm leading-7 text-slate-700">
            {intent.generated.aiBidBrief}
          </p>
          <div className="mt-5 grid gap-3 md:grid-cols-3">
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
              <CalendarClock size={18} className="text-blue-700" aria-hidden="true" />
              <p className="mt-3 text-sm font-black text-slate-950">{t("intentsPage.keyDates")}</p>
              <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                {intent.generated.keyDates.publishedDate} / {intent.generated.keyDates.deadlineDate}
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
              <ShieldAlert size={18} className="text-amber-600" aria-hidden="true" />
              <p className="mt-3 text-sm font-black text-slate-950">{t("intentsPage.riskFlags")}</p>
              <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                {intent.generated.riskFlags[0] ?? t("intentsPage.noMajorRisks")}
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
              <FileCheck2 size={18} className="text-emerald-700" aria-hidden="true" />
              <p className="mt-3 text-sm font-black text-slate-950">{t("intentsPage.checklist")}</p>
              <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                {intent.generated.initialChecklist.length} {t("intentsPage.items")}
              </p>
            </div>
          </div>
          <div className="mt-5 rounded-lg border border-blue-100 bg-blue-50/60 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-black text-slate-950">{t("intentsPage.evidenceCitations")}</p>
              <Badge variant="outline" className="border-blue-200 bg-white text-blue-700">
                {qualificationCitations.length}
              </Badge>
            </div>
            <div className="mt-3 rounded-lg border border-blue-100 bg-white p-3">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-black text-slate-950">
                      {t("intentsPage.qualificationFreshness")}
                    </p>
                    <Badge
                      variant="outline"
                      className={`w-fit ${freshnessTone(qualificationFreshness?.status)}`}
                    >
                      {qualificationFreshness
                        ? t(`intentsPage.qualificationFreshnessStatuses.${qualificationFreshness.status}`)
                        : isFreshnessLoading
                          ? t("intentsPage.evidenceCitationsLoading")
                          : t("intentsPage.qualificationFreshnessStatuses.not_refreshed")}
                    </Badge>
                  </div>
                  <p className="mt-2 text-xs font-semibold leading-5 text-slate-500">
                    {qualificationFreshness?.status === "stale"
                      ? t("intentsPage.qualificationFreshnessStale")
                      : qualificationFreshness?.status === "current"
                        ? t("intentsPage.qualificationFreshnessCurrent")
                        : t("intentsPage.qualificationFreshnessNotRefreshed")}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs font-bold text-slate-500">
                    <span>
                      {t("intentsPage.qualificationSignalCount").replace(
                        "{count}",
                        String(qualificationFreshness?.signalCount ?? 0),
                      )}
                    </span>
                    <span>
                      {t("intentsPage.qualificationLastRefreshed").replace(
                        "{date}",
                        formatEvidenceDate(qualificationFreshness?.lastRefreshedAt ?? null)
                          || t("intentsPage.notAvailable"),
                      )}
                    </span>
                  </div>
                  {qualificationFreshness?.latestSignal ? (
                    <p className="mt-2 line-clamp-2 break-words text-xs font-semibold leading-5 text-amber-700">
                      {t("intentsPage.qualificationLatestSignal")}: {qualificationFreshness.latestSignal.label}
                    </p>
                  ) : (
                    <p className="mt-2 text-xs font-semibold text-slate-400">
                      {t("intentsPage.qualificationNoSignals")}
                    </p>
                  )}
                </div>
                <Button
                  type="button"
                  onClick={() => void handleRefreshQualificationEvidence()}
                  disabled={!intent || isFreshnessLoading || isRefreshingQualification}
                  variant="outline"
                  className="w-fit rounded-lg border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100"
                >
                  <RefreshCcw
                    size={15}
                    className={`mr-2 ${isRefreshingQualification ? "animate-spin" : ""}`}
                    aria-hidden="true"
                  />
                  {isRefreshingQualification
                    ? t("intentsPage.refreshingQualificationEvidence")
                    : t("intentsPage.refreshQualificationEvidence")}
                </Button>
              </div>
              {qualificationRefreshError ? (
                <p className="mt-2 text-xs font-semibold text-rose-600">
                  {t("intentsPage.qualificationRefreshError")}
                </p>
              ) : null}
            </div>
            {isCitationsLoading ? (
              <p className="mt-3 text-sm font-semibold text-slate-500">{t("intentsPage.evidenceCitationsLoading")}</p>
            ) : qualificationCitations.length === 0 ? (
              <p className="mt-3 text-sm font-semibold text-slate-500">{t("intentsPage.noEvidenceCitations")}</p>
            ) : (
              <div className="mt-3 grid gap-2">
                {qualificationCitations.slice(0, 6).map((citation) => {
                  const evidenceUrl = safeEvidenceUrl(citation.url);

                  return (
                    <article key={citation.id} className="rounded-lg border border-blue-100 bg-white p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className="border-slate-200 bg-slate-50 text-slate-600">
                          {t(`intentsPage.citationSections.${citation.section}`)}
                        </Badge>
                        <span className="text-xs font-black text-slate-900">{citation.sourceLabel}</span>
                        <span className="text-xs font-bold text-slate-400">
                          {t(`intentsPage.confidence.${citation.confidence}`)}
                        </span>
                      </div>
                      <p className="mt-2 line-clamp-2 break-words text-xs font-semibold leading-5 text-slate-600">
                        {citation.excerpt}
                      </p>
                      {evidenceUrl ? (
                        <Link
                          href={evidenceUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="mt-2 inline-flex items-center text-xs font-black text-blue-700 hover:text-blue-900"
                        >
                          <ExternalLink size={13} className="mr-1.5" aria-hidden="true" />
                          {t("intentsPage.openEvidence")}
                        </Link>
                      ) : null}
                    </article>
                  );
                })}
              </div>
            )}
          </div>
          <div className={`mt-4 rounded-lg border p-4 ${
            qualificationQaFeature.enabled ? "border-slate-200 bg-white" : "border-amber-200 bg-amber-50/60"
          }`}>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-sm font-black text-slate-950">{t("intentsPage.askEvidenceQuestion")}</p>
                <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                  {qualificationQaFeature.enabled
                    ? t("intentsPage.groundedByEvidence")
                    : lockedFeatureMessage("bid.brief.full.generate")}
                </p>
              </div>
              {qaAnswer ? (
                <Badge variant="outline" className="w-fit border-emerald-200 bg-emerald-50 text-emerald-700">
                  {t("intentsPage.groundedAnswer")}
                </Badge>
              ) : null}
            </div>
            {qualificationQaFeature.enabled ? (
              <div className="mt-3 grid gap-3">
                <textarea
                  value={qaQuestion}
                  onChange={(event) => setQaQuestion(event.target.value)}
                  disabled={isQaLoading}
                  placeholder={t("intentsPage.askEvidenceQuestionPlaceholder")}
                  className="min-h-20 w-full resize-y rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2 text-sm font-semibold leading-6 outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10"
                />
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <Button
                    onClick={() => void handleAskEvidenceQuestion()}
                    disabled={isQaLoading || !qaQuestion.trim()}
                    className="w-fit rounded-lg bg-slate-950 text-white hover:bg-slate-800"
                  >
                    {isQaLoading ? t("intentsPage.askingQuestion") : t("intentsPage.askQuestion")}
                  </Button>
                  <p className="min-h-5 text-sm font-semibold text-slate-500">
                    {qaError ? t("intentsPage.qaError") : ""}
                  </p>
                </div>
                {qaAnswer ? (
                  <div className="rounded-lg border border-emerald-100 bg-emerald-50/60 p-4">
                    <p className="text-sm font-black text-slate-950">{t("intentsPage.groundedAnswer")}</p>
                    <p className="mt-2 whitespace-pre-wrap break-words text-sm font-semibold leading-7 text-slate-700">
                      {qaAnswer.answer}
                    </p>
                    <div className="mt-4 rounded-lg border border-emerald-100 bg-white p-3">
                      <div className="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <p className="text-xs font-black uppercase text-slate-500">
                            {t("intentsPage.aiRunMetadata")}
                          </p>
                          <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                            {t("intentsPage.aiDeterministicNoLlmNotice")}
                          </p>
                        </div>
                        {qaAnswer.creditUsage ? (
                          <Badge variant="outline" className="w-fit border-blue-100 bg-blue-50 text-blue-700">
                            {t("intentsPage.creditDryRun")}
                          </Badge>
                        ) : null}
                      </div>
                      {qaAiRun ? (
                        <dl className="mt-3 grid gap-2 text-xs sm:grid-cols-2">
                          <div>
                            <dt className="font-black text-slate-500">{t("intentsPage.aiProvider")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">{qaAiRun.provider}</dd>
                          </div>
                          <div>
                            <dt className="font-black text-slate-500">{t("intentsPage.aiModelOrRulesVersion")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">
                              {qaAiRun.model} / {qaAiRun.rulesVersion}
                            </dd>
                          </div>
                          <div>
                            <dt className="font-black text-slate-500">{t("intentsPage.aiPromptVersion")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">
                              {qaAiRun.promptVersion}
                            </dd>
                          </div>
                          <div>
                            <dt className="font-black text-slate-500">{t("intentsPage.aiConfidence")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">
                              {t(`intentsPage.confidence.${qaAiRun.confidence}`)}
                            </dd>
                          </div>
                          <div>
                            <dt className="font-black text-slate-500">{t("intentsPage.aiCostTotal")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">
                              ${qaAiRun.cost.total}
                            </dd>
                          </div>
                          <div>
                            <dt className="font-black text-slate-500">{t("intentsPage.aiFallbackReason")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">
                              {qaAiRun.fallbackReason}
                            </dd>
                          </div>
                          <div className="sm:col-span-2">
                            <dt className="font-black text-slate-500">{t("intentsPage.aiGeneratedAt")}</dt>
                            <dd className="mt-0.5 break-words font-semibold text-slate-700">
                              {qaAiRun.generatedAt}
                            </dd>
                          </div>
                        </dl>
                      ) : (
                        <p className="mt-3 text-xs font-semibold text-slate-500">
                          {t("intentsPage.aiMetadataUnavailable")}
                        </p>
                      )}
                      {qaAnswer.creditUsage ? (
                        <div className="mt-3 rounded-lg border border-blue-100 bg-blue-50/60 p-3 text-xs font-semibold text-blue-900">
                          <span className="font-black">{t("intentsPage.creditChargedAmount")}:</span>{" "}
                          chargedAmount={qaAnswer.creditUsage.chargedAmount}
                        </div>
                      ) : null}
                    </div>
                    <p className="mt-4 text-xs font-black uppercase text-slate-400">
                      {t("intentsPage.answerEvidence")}
                    </p>
                    <div className="mt-2 grid gap-2">
                      {qaAnswer.citations.map((citation) => {
                        const evidenceUrl = safeEvidenceUrl(citation.url);

                        return (
                          <article key={citation.id} className="rounded-lg border border-emerald-100 bg-white p-3">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge variant="outline" className="border-slate-200 bg-slate-50 text-slate-600">
                                {t(`intentsPage.citationSections.${citation.section}`)}
                              </Badge>
                              <span className="text-xs font-black text-slate-900">{citation.sourceLabel}</span>
                            </div>
                            <p className="mt-2 line-clamp-2 break-words text-xs font-semibold leading-5 text-slate-600">
                              {citation.excerpt}
                            </p>
                            {evidenceUrl ? (
                              <Link
                                href={evidenceUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="mt-2 inline-flex items-center text-xs font-black text-blue-700 hover:text-blue-900"
                              >
                                <ExternalLink size={13} className="mr-1.5" aria-hidden="true" />
                                {t("intentsPage.openEvidence")}
                              </Link>
                            ) : null}
                          </article>
                        );
                      })}
                    </div>
                  </div>
                ) : null}
              </div>
            ) : (
              <p className="mt-3 text-sm font-semibold leading-6 text-amber-800">
                {lockedFeatureMessage("bid.brief.full.generate")}
              </p>
            )}
          </div>
        </article>

        <aside className="winbids-panel rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
            {t("intentsPage.moduleMap")}
          </p>
          <h2 className="mt-1 text-2xl font-black text-slate-950">{t("intentsPage.pursuitModules")}</h2>
          <div className="mt-5 grid gap-3">
            {[
              ["match", Target],
              ["brief", Sparkles],
              ["submission", Route],
              ["compliance", FileCheck2],
              ["decision", ClipboardCheck],
              ["response", PackageCheck],
              ["award", PackageCheck],
            ].map(([key, Icon]) => {
              const ModuleIcon = Icon as typeof Target;
              const isSubmissionLocked = key === "submission" && !submissionGuidanceFeature.enabled;
              const isComplianceLocked = key === "compliance" && !complianceManifestFeature.enabled;
              const isDecisionLocked = key === "decision" && !pursuitDecisionFeature.enabled;
              const isResponseLocked = key === "response" && !responseWorkspaceFeature.enabled;
              const isLocked = isSubmissionLocked || isComplianceLocked || isDecisionLocked || isResponseLocked;
              const requiredTier = isComplianceLocked
                ? complianceManifestFeature.requiredTier
                : isDecisionLocked
                  ? pursuitDecisionFeature.requiredTier
                  : isResponseLocked
                    ? responseWorkspaceFeature.requiredTier
                  : submissionGuidanceFeature.requiredTier;
              const lockedMessage = isComplianceLocked
                ? lockedFeatureMessage("compliance_manifest")
                : isDecisionLocked
                  ? lockedFeatureMessage("pursue_no_bid")
                  : isResponseLocked
                    ? lockedFeatureMessage("response.workspace.create")
                  : lockedFeatureMessage("submission_guidance");
              return (
                <div
                  key={key as string}
                  className={`flex gap-3 rounded-lg border p-4 ${
                    isLocked ? "border-amber-200 bg-amber-50/60" : "border-slate-200 bg-white"
                  }`}
                >
                  {isLocked ? (
                    <LockKeyhole className="mt-0.5 shrink-0 text-amber-700" size={18} aria-hidden="true" />
                  ) : (
                    <ModuleIcon className="mt-0.5 shrink-0 text-blue-700" size={18} aria-hidden="true" />
                  )}
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-black text-slate-950">
                        {t(`intentsPage.moduleItems.${key as string}.title`)}
                      </p>
                      {isLocked && (
                        <Badge variant="outline" className="border-amber-200 bg-white text-amber-700">
                          {requiredTier}
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                      {isLocked
                        ? lockedMessage
                        : t(`intentsPage.moduleItems.${key as string}.description`)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </aside>
      </section>

      <section className="grid gap-4 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
        <article className="winbids-panel rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="flex items-center gap-2 text-xl font-black text-slate-950">
            <CheckCircle2 size={19} className="text-emerald-700" aria-hidden="true" />
            {t("intentsPage.checklist")}
          </h2>
          <ul className="mt-4 space-y-3">
            {intent.generated.initialChecklist.map((item) => (
              <li key={item} className="flex gap-2 text-sm leading-6 text-slate-700">
                <CheckCircle2 size={16} className="mt-1 shrink-0 text-emerald-600" />
                <span className="break-words">{item}</span>
              </li>
            ))}
          </ul>
        </article>

        <article className="winbids-panel rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="flex items-center gap-2 text-xl font-black text-slate-950">
            <Target size={19} className="text-blue-700" aria-hidden="true" />
            {t("intentsPage.matchSnapshot")}
          </h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {matchComponents.map(([key, value]) => (
              <div key={key} className="rounded-lg border border-slate-100 bg-slate-50/70 p-3">
                <p className="text-xs font-black uppercase text-slate-400">{metricLabel(key)}</p>
                <p className="mt-1 text-sm font-bold text-slate-900">{value}</p>
              </div>
            ))}
          </div>
          <p className="mt-4 break-words text-sm leading-6 text-slate-600">{intent.match.explanation}</p>
        </article>
      </section>

      <section
        className={`winbids-panel pursuitDecision rounded-lg border p-5 shadow-sm ${
          pursuitDecisionFeature.enabled ? "border-slate-200 bg-white" : "border-amber-200 bg-amber-50/60"
        }`}
      >
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
              {pursuitDecisionFeature.enabled
                ? t("intentsPage.pursuitDecision")
                : t("intentsPage.nextPhasePreview")}
            </p>
            <h2 className="mt-1 flex items-center gap-2 text-2xl font-black text-slate-950">
              <ClipboardCheck size={21} className="text-blue-700" aria-hidden="true" />
              {t("intentsPage.pursuitDecision")}
            </h2>
          </div>
          <span className="w-fit rounded-full border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
            {pursuitDecisionFeature.enabled
              ? pursuitDecisionBoard
                ? t(`intentsPage.pursuitRecommendations.${pursuitDecisionBoard.recommendation.recommendation}`)
                : t("intentsPage.pursuitDecisionLoading")
              : lockedFeatureMessage("pursue_no_bid")}
          </span>
        </div>

        {!pursuitDecisionFeature.enabled ? (
          <LockedFeatureState
            message={lockedFeatureMessage("pursue_no_bid")}
            title={t("intentsPage.pursuitDecision")}
          />
        ) : (
          <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,0.95fr)_minmax(300px,1.05fr)]">
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
              <p className="text-sm font-black text-slate-950">{t("intentsPage.recommendation")}</p>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="border-blue-100 bg-blue-50 text-blue-700">
                  {pursuitDecisionBoard
                    ? t(`intentsPage.pursuitRecommendations.${pursuitDecisionBoard.recommendation.recommendation}`)
                    : t("intentsPage.pursuitDecisionLoading")}
                </Badge>
                {pursuitDecisionBoard && (
                  <Badge variant="outline" className="border-slate-200 bg-white text-slate-700">
                    {t(`intentsPage.pursuitConfidence.${pursuitDecisionBoard.recommendation.confidence}`)}
                  </Badge>
                )}
              </div>
              <ul className="mt-4 space-y-2">
                {(pursuitDecisionBoard?.recommendation.reasons ?? [t("intentsPage.pursuitDecisionLoading")]).map((reason) => (
                  <li key={reason} className="flex gap-2 text-sm font-semibold leading-6 text-slate-700">
                    <ShieldAlert size={16} className="mt-1 shrink-0 text-amber-600" aria-hidden="true" />
                    <span className="break-words">{reason}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-5">
                <p className="text-xs font-black uppercase text-slate-400">
                  {t("intentsPage.reasonTaxonomy")}
                </p>
                <div className="mt-3 grid gap-3">
                  {(pursuitDecisionBoard?.recommendation.reasonDetails ?? []).map((detail) => (
                    <article key={`${detail.category}-${detail.summary}`} className="rounded-lg border border-slate-200 bg-white p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className="border-blue-100 bg-blue-50 text-blue-700">
                          {t(`intentsPage.pursuitReasonCategories.${detail.category}`)}
                        </Badge>
                        <Badge variant="outline" className="border-slate-200 bg-slate-50 text-slate-700">
                          {t(`intentsPage.pursuitReasonSeverities.${detail.severity}`)}
                        </Badge>
                      </div>
                      <p className="mt-2 break-words text-sm font-black leading-6 text-slate-950">
                        {detail.summary}
                      </p>
                      <p className="mt-1 break-words text-xs font-semibold leading-5 text-slate-600">
                        {detail.explanation}
                      </p>
                      <div className="mt-3 grid gap-2 rounded-lg border border-slate-100 bg-slate-50/70 p-3">
                        <div>
                          <p className="text-xs font-black text-slate-700">{t("intentsPage.linkedEvidence")}:</p>
                          {detail.evidenceRefs.length > 0 ? (
                            <div className="mt-2 flex flex-wrap gap-2">
                              {detail.evidenceRefs.map((ref) => {
                                const url = evidenceRefUrl(ref);
                                const key = `${ref.kind}-${ref.citationId ?? ref.url ?? ref.label}`;
                                const chipClassName = "inline-flex min-h-7 items-center rounded-md border border-blue-100 bg-white px-2 py-1 text-xs font-black text-blue-700";

                                return url ? (
                                  <Link
                                    key={key}
                                    href={url}
                                    target={url.startsWith("/") ? undefined : "_blank"}
                                    rel={url.startsWith("/") ? undefined : "noreferrer"}
                                    className={`${chipClassName} hover:border-blue-200 hover:bg-blue-50`}
                                  >
                                    <ExternalLink size={12} className="mr-1.5 shrink-0" aria-hidden="true" />
                                    <span className="break-words">{ref.label}</span>
                                  </Link>
                                ) : (
                                  <span key={key} className={`${chipClassName} text-slate-600`}>
                                    {ref.label}
                                  </span>
                                );
                              })}
                            </div>
                          ) : (
                            <p className="mt-1 text-xs font-bold leading-5 text-slate-500">
                              {detail.evidenceLabel}
                            </p>
                          )}
                        </div>
                        <p className="text-xs font-bold leading-5 text-slate-500">
                          <span className="font-black text-slate-700">{t("intentsPage.suggestedAction")}:</span>{" "}
                          {detail.suggestedAction}
                        </p>
                      </div>
                    </article>
                  ))}
                  {pursuitDecisionBoard && pursuitDecisionBoard.recommendation.reasonDetails.length === 0 ? (
                    <p className="text-sm font-semibold text-slate-500">{t("intentsPage.noReasonDetails")}</p>
                  ) : null}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid gap-3 md:grid-cols-2">
                <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                  {t("intentsPage.decision")}
                  <Select
                    value={pursuitDecisionDraft.decision}
                    onValueChange={(value) =>
                      setPursuitDecisionDraft((current) => ({
                        ...current,
                        decision: value as PursuitDecisionValue,
                      }))
                    }
                    disabled={isPursuitDecisionLoading || isPursuitDecisionSaving}
                  >
                    <SelectTrigger className="h-9 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                      {pursuitDecisionOptions.map((decision) => (
                        <SelectItem key={decision} value={decision}>
                          {t(`intentsPage.pursuitDecisions.${decision}`)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>

                <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                  {t("intentsPage.decisionReasons")}
                  <textarea
                    value={pursuitDecisionDraft.reasons}
                    onChange={(event) =>
                      setPursuitDecisionDraft((current) => ({ ...current, reasons: event.target.value }))
                    }
                    disabled={isPursuitDecisionLoading || isPursuitDecisionSaving}
                    placeholder={t("intentsPage.decisionReasonsPlaceholder")}
                    className="min-h-20 w-full resize-y rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10"
                  />
                </label>
              </div>

              <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                {t("intentsPage.decisionNotes")}
                <textarea
                  value={pursuitDecisionDraft.notes}
                  onChange={(event) =>
                    setPursuitDecisionDraft((current) => ({ ...current, notes: event.target.value }))
                  }
                  disabled={isPursuitDecisionLoading || isPursuitDecisionSaving}
                  placeholder={t("intentsPage.decisionNotesPlaceholder")}
                  className="min-h-20 w-full resize-y rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10"
                />
              </label>

              <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                <Button
                  onClick={() => void handleSavePursuitDecision()}
                  disabled={isPursuitDecisionLoading || isPursuitDecisionSaving}
                  className="w-fit rounded-lg bg-slate-950 text-white hover:bg-slate-800"
                >
                  {isPursuitDecisionSaving ? t("intentsPage.submissionSaving") : t("intentsPage.savePursuitDecision")}
                </Button>
                <p className="min-h-5 text-sm font-semibold text-slate-500">
                  {pursuitDecisionError
                    ? t("intentsPage.pursuitDecisionSaveError")
                    : pursuitDecisionNotice}
                </p>
              </div>

              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <p className="text-sm font-black text-slate-950">{t("intentsPage.decisionHistory")}</p>
                <div className="mt-3 space-y-2">
                  {(pursuitDecisionBoard?.history.length ? pursuitDecisionBoard.history : []).map((decision) => (
                    <div key={decision.id} className="rounded-lg border border-slate-100 bg-slate-50/70 p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className="border-slate-200 bg-white text-slate-700">
                          {t(`intentsPage.pursuitDecisions.${decision.decision}`)}
                        </Badge>
                        <span className="text-xs font-bold text-slate-400">{decision.createdAt}</span>
                      </div>
                      {decision.reasons.length > 0 && (
                        <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
                          {decision.reasons.join(" / ")}
                        </p>
                      )}
                      {decision.notes && (
                        <p className="mt-1 text-sm leading-6 text-slate-500">{decision.notes}</p>
                      )}
                    </div>
                  ))}
                  {!pursuitDecisionBoard?.history.length && (
                    <p className="text-sm font-semibold text-slate-500">{t("intentsPage.noDecisionHistory")}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      <ResponseWorkspacePanel
        assigneeOptions={responseWorkspaceAssigneeOptions}
        availableArtifacts={artifactVault?.artifacts ?? []}
        commentDrafts={responseWorkspaceCommentDrafts}
        commentsByItemId={responseWorkspaceCommentsByItemId}
        error={responseWorkspaceError}
        featureEnabled={responseWorkspaceFeature.enabled}
        isLoading={isResponseWorkspaceLoading}
        isPackageSaving={isResponsePackageSaving}
        exportingSnapshotId={responsePackageExportingSnapshotId}
        lockedMessage={lockedFeatureMessage("response.workspace.create")}
        notice={responseWorkspaceNotice}
        onCommentDraftsChange={setResponseWorkspaceCommentDrafts}
        onCreateComment={(item) => void handleCreateResponseWorkspaceComment(item)}
        onCreatePackageExport={(snapshotId, formatOption) => void handleCreateResponsePackageExport(snapshotId, formatOption)}
        onCreatePackageSnapshot={() => void handleCreateResponsePackageSnapshot()}
        onReviewPackageExport={(exportId, reviewStatus, reviewNotes) =>
          void handleReviewResponsePackageExport(exportId, reviewStatus, reviewNotes)
        }
        onLocalItemUpdate={updateLocalResponseWorkspaceItem}
        onSaveLinkedArtifacts={(item, linkedArtifactIds) =>
          void handleSaveResponseWorkspaceLinkedArtifacts(item, linkedArtifactIds)
        }
        onSaveItem={(item, patch) => void handleResponseWorkspaceItemUpdate(item, patch)}
        savingCommentItemId={responseWorkspaceSavingCommentItemId}
        savingItemId={responseWorkspaceSavingItemId}
        reviewingExportId={responsePackageReviewingExportId}
        t={t}
        packageWorkspace={responsePackageWorkspace}
        workspace={responseWorkspace}
      />

      <ArtifactVaultPanel
        draft={artifactDraft}
        error={artifactVaultError}
        featureEnabled={artifactVaultFeature.enabled}
        isLoading={isArtifactVaultLoading}
        deletingArtifactId={deletingArtifactId}
        replacingArtifactId={replacingArtifactId}
        isUploading={isArtifactUploading}
        lockedMessage={lockedFeatureMessage("artifact.vault.upload")}
        notice={artifactVaultNotice}
        onDraftChange={setArtifactDraft}
        onDelete={handleDeleteSupplierArtifact}
        onReplace={handleReplaceSupplierArtifact}
        onUpload={() => void handleUploadArtifact()}
        t={t}
        vault={artifactVault}
      />

      <section className="winbids-panel procurementReadModels rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
              {t("intentsPage.procurementReadModels")}
            </p>
            <h2 className="mt-1 text-2xl font-black text-slate-950">{t("intentsPage.workflowIntelligence")}</h2>
          </div>
          <span className="w-fit rounded-full border border-blue-100 bg-blue-50 px-3 py-2 text-xs font-black text-blue-700">
            {t("intentsPage.localDeterministicSummaries")}
          </span>
        </div>

        <div className="mt-5 grid gap-4 lg:grid-cols-3">
          <article className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
            <p className="text-xs font-black uppercase text-slate-500">{t("intentsPage.quoteComparisonSummary")}</p>
            {quoteComparisonSummary ? (
              <div className="mt-3 space-y-3">
                <div className="grid gap-2 sm:grid-cols-2">
                  {quoteComparisonMetrics.map(([label, value]) => (
                    <div key={label} className="rounded-lg border border-slate-200 bg-white p-3">
                      <p className="text-[11px] font-black uppercase text-slate-400">{label}</p>
                      <p className="mt-1 text-sm font-black text-slate-950">
                        {formatCentsAmount(value, quoteComparisonSummary.currency)}
                      </p>
                    </div>
                  ))}
                </div>
                <p className="text-xs font-bold leading-5 text-slate-600">
                  {t("intentsPage.quoteComparisonPricedQuotes").replace("{count}", String(quoteComparisonSummary.quotedCount))}
                  {quoteComparisonSummary.variancePercent !== null
                    ? `, ${t("intentsPage.quoteComparisonVariance").replace("{percent}", String(quoteComparisonSummary.variancePercent))}`
                    : ""}
                </p>
                {quoteComparisonSummary.recommendedReviewFlags.length > 0 ? (
                  <ul className="space-y-2">
                    {quoteComparisonSummary.recommendedReviewFlags.map((flag) => (
                      <li key={flag.code} className="rounded-md border border-amber-200 bg-amber-50 p-2 text-xs font-bold leading-5 text-amber-800">
                        <span className="font-black">{flag.code}:</span> {flag.message}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs font-bold text-emerald-700">{t("intentsPage.quoteComparisonNoFlags")}</p>
                )}
              </div>
            ) : (
              <p className="mt-3 text-sm font-semibold leading-6 text-slate-500">
                {t("intentsPage.quoteComparisonUnavailable")}
              </p>
            )}
          </article>

          <article className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
            <p className="text-xs font-black uppercase text-slate-500">{t("intentsPage.winLossLearningSummary")}</p>
            {learningSummary ? (
              <div className="mt-3 space-y-3">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="border-blue-100 bg-white text-blue-700">
                    {learningSummary.outcomeClass}
                  </Badge>
                  <Badge variant="outline" className="border-slate-200 bg-white text-slate-700">
                    {learningSummary.primaryDriver}
                  </Badge>
                </div>
                <p className="text-sm font-black leading-6 text-slate-950">{learningSummary.headline}</p>
                <ul className="space-y-2">
                  {learningSummary.lessons.map((lesson) => (
                    <li key={lesson} className="text-xs font-semibold leading-5 text-slate-600">
                      {lesson}
                    </li>
                  ))}
                </ul>
                {learningSummary.recommendedActions.length > 0 ? (
                  <p className="text-xs font-bold leading-5 text-slate-600">
                    {t("intentsPage.winLossRecommendedActions").replace("{actions}", learningSummary.recommendedActions.join(", "))}
                  </p>
                ) : null}
              </div>
            ) : (
              <p className="mt-3 text-sm font-semibold leading-6 text-slate-500">
                {t("intentsPage.winLossLearningUnavailable")}
              </p>
            )}
          </article>

          <article className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
            <p className="text-xs font-black uppercase text-slate-500">{t("intentsPage.evidenceLinksSummary")}</p>
            <p className="mt-3 text-sm font-black leading-6 text-slate-950">{evidenceAutoLinkSummary}</p>
            <dl className="mt-3 grid gap-2 text-xs font-bold text-slate-600">
              <div className="flex items-center justify-between gap-3 rounded-md border border-slate-200 bg-white px-3 py-2">
                <dt>{t("intentsPage.evidenceLinksPackageExports")}</dt>
                <dd>{submissionEvidenceLinks.responsePackageExports.length}</dd>
              </div>
              <div className="flex items-center justify-between gap-3 rounded-md border border-slate-200 bg-white px-3 py-2">
                <dt>{t("intentsPage.evidenceLinksSupplierArtifacts")}</dt>
                <dd>{submissionEvidenceLinks.linkedSupplierArtifacts.length}</dd>
              </div>
              <div className="flex items-center justify-between gap-3 rounded-md border border-slate-200 bg-white px-3 py-2">
                <dt>{t("intentsPage.evidenceLinksAwardNotice")}</dt>
                <dd>{submissionEvidenceLinks.awardOutcome ? 1 : 0}</dd>
              </div>
            </dl>
          </article>
        </div>
      </section>

      <QuoteWorkspacePanel
        artifactVault={artifactVault}
        draft={quoteDraft}
        error={quoteError}
        featureEnabled={quoteWorkflowFeature.enabled}
        isLoading={isQuoteWorkspaceLoading}
        isSaving={isQuoteSaving}
        lockedMessage={lockedFeatureMessage("quote_workflow")}
        notice={quoteNotice}
        onCreateRequest={() => void handleCreateQuoteRequest()}
        onDraftChange={setQuoteDraft}
        onUpdateRequest={(request, patch) => void handleQuoteRequestUpdate(request, patch)}
        savingRequestId={quoteSavingRequestId}
        t={t}
        workspace={quoteWorkspace}
      />

      <DeadlineNotificationsPanel
        error={deadlineError}
        featureEnabled={deadlineNotificationsFeature.enabled}
        isLoading={isDeadlineWorkspaceLoading}
        lockedMessage={lockedFeatureMessage("deadline_notifications")}
        notice={deadlineNotice}
        onUpdateReminder={(reminder, action) => void handleDeadlineReminderUpdate(reminder, action)}
        savingReminderId={deadlineSavingReminderId}
        t={t}
        workspace={deadlineWorkspace}
      />

      <AwardWinLossPanel
        key={awardOutcome?.updatedAt ?? awardOutcome?.id ?? "award-outcome"}
        availableArtifacts={artifactVault?.artifacts ?? []}
        error={awardOutcomeError}
        featureEnabled={awardOutcomeFeature.enabled}
        isLoading={isAwardOutcomeLoading}
        isSaving={isAwardOutcomeSaving}
        lockedMessage={lockedFeatureMessage("award.tabulation.analyze")}
        notice={awardOutcomeNotice}
        onUpdate={(patch) => void handleAwardOutcomeUpdate(patch)}
        outcome={awardOutcome}
        t={t}
      />

      <section
        aria-label={t("intentsPage.knowledgeStationCoachAriaLabel")}
        className={`winbids-panel knowledgeStation rounded-lg border p-5 shadow-sm ${
          knowledgeStationFeature.enabled ? "border-slate-200 bg-white" : "border-amber-200 bg-amber-50/60"
        }`}
      >
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
              {knowledgeStationFeature.enabled ? t("knowledge.library") : t("knowledge.lockedTitle")}
            </p>
            <h2 className="mt-1 flex items-center gap-2 text-2xl font-black text-slate-950">
              <Sparkles size={21} className="text-blue-700" aria-hidden="true" />
              {t("knowledge.title")}
            </h2>
          </div>
          <span className="w-fit rounded-full border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
            {knowledgeStationFeature.enabled
              ? `${knowledgeItems.length}/10 ${t("knowledge.recentItems")}`
              : lockedFeatureMessage("knowledge_station")}
          </span>
        </div>

        {!knowledgeStationFeature.enabled ? (
          <LockedFeatureState
            message={`${t("knowledge.lockedBody")} ${lockedFeatureMessage("knowledge_station")}`}
            title={t("knowledge.lockedTitle")}
          />
        ) : (
          <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(300px,0.9fr)]">
            <div className="space-y-4">
              <div>
                <p className="text-sm font-black text-slate-950">{t("knowledge.workflowCoach")}</p>
                <div className="mt-3 grid gap-3">
                  {workflowCoachCards.map((card) => {
                    const sourceUrl = card.href ? safeEvidenceUrl(card.href) : "";

                    return (
                      <article key={card.id} className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge variant="outline" className="border-blue-100 bg-blue-50 text-blue-700">
                                {card.category}
                              </Badge>
                              <Badge variant="outline" className="border-slate-200 bg-white text-slate-700">
                                {card.severity}
                              </Badge>
                            </div>
                            <p className="mt-2 break-words text-sm font-black leading-6 text-slate-950">
                              {card.title}
                            </p>
                            <p className="mt-1 break-words text-sm font-semibold leading-6 text-slate-600">
                              {card.guidance}
                            </p>
                            <p className="mt-2 break-words text-xs font-bold leading-5 text-slate-500">
                              <span className="font-black text-slate-700">{t("intentsPage.suggestedAction")}:</span>{" "}
                              {card.suggestedAction}
                            </p>
                            {sourceUrl ? (
                              <Link
                                href={sourceUrl}
                                target={sourceUrl.startsWith("/") ? undefined : "_blank"}
                                rel={sourceUrl.startsWith("/") ? undefined : "noreferrer"}
                                className="mt-2 inline-flex items-center text-xs font-black text-blue-700 hover:text-blue-900"
                              >
                                <ExternalLink size={13} className="mr-1.5" aria-hidden="true" />
                                {card.sourceLabel ?? t("intentsPage.openEvidence")}
                              </Link>
                            ) : null}
                          </div>
                          <Button
                            type="button"
                            onClick={() => void handleSaveCoachKnowledge(card)}
                            disabled={isKnowledgeSaving}
                            variant="outline"
                            className="w-fit rounded-lg border-slate-200 bg-white text-slate-700"
                          >
                            {savingKnowledgeCoachCardId === card.id
                              ? t("intentsPage.submissionSaving")
                              : t("knowledge.saveFromCoach")}
                          </Button>
                        </div>
                      </article>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <p className="text-sm font-black text-slate-950">{t("knowledge.createNote")}</p>
                <div className="mt-3 grid gap-3">
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("knowledge.titleField")}
                    <Input
                      value={knowledgeDraft.title}
                      onChange={(event) =>
                        setKnowledgeDraft((current) => ({ ...current, title: event.target.value }))
                      }
                      disabled={isKnowledgeSaving}
                      className="h-9 border-slate-200 bg-white"
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("knowledge.type")}
                    <Select
                      value={knowledgeDraft.type}
                      onValueChange={(value) =>
                        setKnowledgeDraft((current) => ({ ...current, type: value as KnowledgeItem["type"] }))
                      }
                      disabled={isKnowledgeSaving}
                    >
                      <SelectTrigger className="h-9 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                        {knowledgeTypeOptions.map((type) => (
                          <SelectItem key={type} value={type}>
                            {t(`knowledge.types.${type}`)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </label>
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("knowledge.tags")}
                    <Input
                      value={knowledgeDraft.tags}
                      onChange={(event) =>
                        setKnowledgeDraft((current) => ({ ...current, tags: event.target.value }))
                      }
                      disabled={isKnowledgeSaving}
                      placeholder={t("knowledge.tagsPlaceholder")}
                      className="h-9 border-slate-200 bg-white"
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("knowledge.body")}
                    <textarea
                      value={knowledgeDraft.body}
                      onChange={(event) =>
                        setKnowledgeDraft((current) => ({ ...current, body: event.target.value }))
                      }
                      disabled={isKnowledgeSaving}
                      placeholder={t("knowledge.bodyPlaceholder")}
                      className="min-h-24 w-full resize-y rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10"
                    />
                  </label>
                  <Button
                    type="button"
                    onClick={() => void handleCreateKnowledgeItem()}
                    disabled={isKnowledgeSaving || !knowledgeDraft.title.trim() || !knowledgeDraft.body.trim()}
                    className="w-fit rounded-lg bg-slate-950 text-white hover:bg-slate-800"
                  >
                    {isKnowledgeSaving ? t("intentsPage.submissionSaving") : t("common.save")}
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-black text-slate-950">{t("knowledge.recentItems")}</p>
                  {isKnowledgeLoading ? (
                    <span className="text-xs font-bold text-slate-400">{t("intentsPage.submissionLoading")}</span>
                  ) : null}
                </div>
                <div className="mt-3 grid gap-2">
                  {knowledgeItems.length === 0 && !isKnowledgeLoading ? (
                    <p className="text-sm font-semibold text-slate-500">{t("knowledge.empty")}</p>
                  ) : null}
                  {knowledgeItems.map((item) => (
                    <article key={item.id} className="rounded-lg border border-slate-100 bg-slate-50/70 p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className="border-slate-200 bg-white text-slate-700">
                          {t(`knowledge.types.${item.type}`)}
                        </Badge>
                        <span className="text-xs font-bold text-slate-400">{item.createdAt}</span>
                      </div>
                      <p className="mt-2 break-words text-sm font-black leading-6 text-slate-950">{item.title}</p>
                      <p className="mt-1 line-clamp-2 break-words text-xs font-semibold leading-5 text-slate-600">
                        {item.body}
                      </p>
                      {item.tags.length > 0 ? (
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {item.tags.map((tag) => (
                            <span
                              key={`${item.id}-${tag}`}
                              className="rounded-md border border-blue-100 bg-white px-2 py-1 text-xs font-black text-blue-700"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      ) : null}
                    </article>
                  ))}
                </div>
              </div>

              <p className="min-h-5 text-sm font-semibold text-slate-500">
                {knowledgeError
                  ? knowledgeError.message.toLowerCase().includes("load")
                    ? t("knowledge.loadFailed")
                    : t("knowledge.saveFailed")
                  : knowledgeNotice}
              </p>
              {canViewKnowledgeRetrievalTrace ? (
                <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
                  <div className="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <p className="text-sm font-black text-slate-950">{t("knowledge.retrievalTrace")}</p>
                      <p className="mt-1 text-xs font-semibold leading-5 text-slate-500">
                        {t("knowledge.retrievalTraceOperatorOnly")}
                      </p>
                    </div>
                    <Badge variant="outline" className="w-fit border-slate-200 bg-white text-slate-700">
                      {knowledgeRetrievalTrace?.provider ?? "lexical"}
                    </Badge>
                  </div>
                  {knowledgeRetrievalTrace ? (
                    <dl className="mt-3 grid gap-2 text-xs">
                      <div>
                        <dt className="font-black text-slate-500">{t("knowledge.selectedItemIds")}</dt>
                        <dd className="mt-0.5 break-words font-semibold text-slate-700">
                          {knowledgeRetrievalTrace.selectedItemIds.length > 0
                            ? knowledgeRetrievalTrace.selectedItemIds.join(", ")
                            : t("knowledge.retrievalTraceUnavailable")}
                        </dd>
                      </div>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <div>
                          <dt className="font-black text-slate-500">{t("knowledge.matchedFields")}</dt>
                          <dd className="mt-0.5 break-words font-semibold text-slate-700">
                            {knowledgeRetrievalTrace.matchedFields.length}
                          </dd>
                        </div>
                        <div>
                          <dt className="font-black text-slate-500">{t("knowledge.futureEmbeddingStatus")}</dt>
                          <dd className="mt-0.5 break-words font-semibold text-slate-700">
                            {knowledgeRetrievalTrace.futureEmbeddingStatus.status}
                          </dd>
                        </div>
                      </div>
                    </dl>
                  ) : (
                    <p className="mt-3 text-sm font-semibold text-slate-500">
                      {t("knowledge.retrievalTraceUnavailable")}
                    </p>
                  )}
                </div>
              ) : null}
            </div>
          </div>
        )}
      </section>

      <section
        className={`winbids-panel submissionPath rounded-lg border p-5 shadow-sm ${
          submissionGuidanceFeature.enabled ? "border-slate-200 bg-white" : "border-amber-200 bg-amber-50/60"
        }`}
      >
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
              {submissionGuidanceFeature.enabled
                ? t("intentsPage.submissionGuidance")
                : t("intentsPage.nextPhasePreview")}
            </p>
            <h2 className="mt-1 flex items-center gap-2 text-2xl font-black text-slate-950">
              <Route size={21} className="text-blue-700" aria-hidden="true" />
              {t("intentsPage.submissionPathTitle")}
            </h2>
          </div>
          <span className="w-fit rounded-full border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
            {submissionGuidanceFeature.enabled
              ? submissionGuidance
                ? `${submissionGuidance.complexityScore}/100 ${t("intentsPage.complexityScore")}`
                : t("intentsPage.mediumComplexity")
              : lockedFeatureMessage("submission_guidance")}
          </span>
        </div>

        {!submissionGuidanceFeature.enabled ? (
          <>
            <div className="mt-5 flex flex-wrap items-center gap-3 rounded-lg bg-white/70 p-4 text-sm font-bold text-amber-800">
              <Landmark size={18} className="text-blue-700" aria-hidden="true" />
              <span>{t("intentsPage.externalPortal")}</span>
              <ArrowRight size={15} className="text-slate-400" aria-hidden="true" />
              <ShieldAlert size={18} className="text-blue-700" aria-hidden="true" />
              <span>{t("intentsPage.registrationCheck")}</span>
              <ArrowRight size={15} className="text-slate-400" aria-hidden="true" />
              <Truck size={18} className="text-blue-700" aria-hidden="true" />
              <span>{t("intentsPage.receiptCapture")}</span>
            </div>
            <LockedFeatureState
              message={lockedFeatureMessage("submission_guidance")}
              title={t("intentsPage.submissionGuidance")}
            />
          </>
        ) : (
          <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1.05fr)_minmax(300px,0.95fr)]">
            <div className="space-y-4">
              <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-black text-slate-950">{t("intentsPage.generatedGuidance")}</p>
                    {submissionGuidance ? (
                      <p className="mt-1 text-xs font-black uppercase text-blue-700">
                        {t("intentsPage.submissionStatus")}: {t(`intentsPage.submissionStatuses.${submissionGuidance.status}`)}
                      </p>
                    ) : null}
                    <p className="mt-1 text-sm leading-6 text-slate-600">
                      {isSubmissionLoading
                        ? t("intentsPage.submissionLoading")
                        : submissionGuidance?.guidanceText ?? t("intentsPage.submissionUnavailable")}
                    </p>
                  </div>
                  {submissionDraft.portalUrl ? (
                    <Link
                      href={submissionDraft.portalUrl}
                      target="_blank"
                      rel="noreferrer"
                      className={buttonVariants({
                        variant: "outline",
                        className: "h-9 w-fit rounded-lg border-slate-200 bg-white text-slate-700",
                      })}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      {t("intentsPage.openPortal")}
                    </Link>
                  ) : null}
                </div>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                  {t("intentsPage.method")}
                  <Select
                    value={submissionDraft.method}
                    onValueChange={(value) =>
                      setSubmissionDraft((current) => ({
                        ...current,
                        method: value as SubmissionMethod,
                      }))
                    }
                    disabled={isSubmissionLoading || isSubmissionSaving}
                  >
                    <SelectTrigger className="h-9 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                      {submissionMethods.map((method) => (
                        <SelectItem key={method} value={method}>
                          {t(`intentsPage.submissionMethods.${method}`)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>

                <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                  {t("intentsPage.portalUrl")}
                  <Input
                    value={submissionDraft.portalUrl}
                    onChange={(event) =>
                      setSubmissionDraft((current) => ({ ...current, portalUrl: event.target.value }))
                    }
                    disabled={isSubmissionLoading || isSubmissionSaving}
                    placeholder="https://"
                    className="h-9 border-slate-200 bg-white"
                  />
                </label>

                <label className="grid gap-1.5 text-sm font-bold text-slate-700 md:col-span-2">
                  {t("intentsPage.contactEmail")}
                  <Input
                    value={submissionDraft.contactEmail}
                    onChange={(event) =>
                      setSubmissionDraft((current) => ({ ...current, contactEmail: event.target.value }))
                    }
                    disabled={isSubmissionLoading || isSubmissionSaving}
                    placeholder="procurement@example.gov"
                    className="h-9 border-slate-200 bg-white"
                  />
                </label>
              </div>

              <div className="grid gap-2">
                {[
                  ["requiresRegistration", "registrationCheck"],
                  ["requiresPhysicalDelivery", "physicalDeliveryRequired"],
                  ["requiresAddendaAcknowledgement", "addendaAcknowledgementRequired"],
                ].map(([field, label]) => (
                  <label
                    key={field}
                    className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-bold text-slate-700"
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(submissionDraft[field as keyof SubmissionDraft])}
                      onChange={(event) =>
                        setSubmissionDraft((current) => ({
                          ...current,
                          [field]: event.target.checked,
                        }))
                      }
                      disabled={isSubmissionLoading || isSubmissionSaving}
                      className="size-4 rounded border-slate-300 text-blue-700"
                    />
                    <span>{t(`intentsPage.${label}`)}</span>
                  </label>
                ))}
              </div>

              <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                <Button
                  onClick={() => void handleSaveSubmissionGuidance()}
                  disabled={isSubmissionLoading || isSubmissionSaving}
                  className="w-fit rounded-lg bg-slate-950 text-white hover:bg-slate-800"
                >
                  {isSubmissionSaving ? t("intentsPage.submissionSaving") : t("intentsPage.saveSubmissionGuidance")}
                </Button>
                <p className="min-h-5 text-sm font-semibold text-slate-500">
                  {submissionError
                    ? t("intentsPage.submissionSaveError")
                    : submissionNotice}
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <p className="text-sm font-black text-slate-950">{t("intentsPage.readinessChecklist")}</p>
                <ul className="mt-3 space-y-2">
                  {(submissionGuidance?.readinessChecklist ?? []).map((item) => (
                    <li key={item} className="flex gap-2 text-sm font-semibold leading-6 text-slate-700">
                      <CheckCircle2 size={16} className="mt-1 shrink-0 text-emerald-600" aria-hidden="true" />
                      <span className="break-words">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-lg border border-slate-200 bg-white p-4">
                <p className="text-sm font-black text-slate-950">{t("intentsPage.submissionRiskFlags")}</p>
                <ul className="mt-3 space-y-2">
                  {(submissionGuidance?.riskFlags.length ? submissionGuidance.riskFlags : [t("intentsPage.noMajorRisks")]).map((item) => (
                    <li key={item} className="flex gap-2 text-sm font-semibold leading-6 text-slate-700">
                      <ShieldAlert size={16} className="mt-1 shrink-0 text-amber-600" aria-hidden="true" />
                      <span className="break-words">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-lg border border-blue-100 bg-blue-50/50 p-4">
                <p className="text-sm font-black text-slate-950">{t("intentsPage.confirmSubmission")}</p>
                <div className="mt-3 grid gap-3">
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("intentsPage.submittedAt")}
                    <Input
                      type="datetime-local"
                      value={confirmationDraft.submittedAt}
                      onChange={(event) =>
                        setConfirmationDraft((current) => ({ ...current, submittedAt: event.target.value }))
                      }
                      disabled={isConfirmationSaving}
                      className="h-9 border-slate-200 bg-white"
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("intentsPage.method")}
                    <Select
                      value={confirmationDraft.method}
                      onValueChange={(value) =>
                        setConfirmationDraft((current) => ({
                          ...current,
                          method: value as SubmissionMethod,
                        }))
                      }
                      disabled={isConfirmationSaving}
                    >
                      <SelectTrigger className="h-9 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                        {submissionMethods.map((method) => (
                          <SelectItem key={method} value={method}>
                            {t(`intentsPage.submissionMethods.${method}`)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </label>
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("intentsPage.confirmationReference")}
                    <Input
                      value={confirmationDraft.confirmationReference}
                      onChange={(event) =>
                        setConfirmationDraft((current) => ({
                          ...current,
                          confirmationReference: event.target.value,
                        }))
                      }
                      disabled={isConfirmationSaving}
                      className="h-9 border-slate-200 bg-white"
                    />
                  </label>
                  <label className="grid gap-1.5 text-sm font-bold text-slate-700">
                    {t("intentsPage.confirmationNotes")}
                    <textarea
                      value={confirmationDraft.confirmationNotes}
                      onChange={(event) =>
                        setConfirmationDraft((current) => ({
                          ...current,
                          confirmationNotes: event.target.value,
                        }))
                      }
                      disabled={isConfirmationSaving}
                      className="min-h-20 w-full resize-y rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10"
                    />
                  </label>
                  <Button
                    onClick={() => void handleConfirmSubmission()}
                    disabled={isConfirmationSaving || !confirmationDraft.submittedAt}
                    className="w-fit rounded-lg bg-blue-700 text-white hover:bg-blue-800"
                  >
                    {isConfirmationSaving ? t("intentsPage.submissionSaving") : t("intentsPage.confirmSubmission")}
                  </Button>
                  {submissionConfirmation ? (
                    <p className="text-sm font-semibold text-blue-900">
                      {t("intentsPage.latestConfirmation")}: {submissionConfirmation.confirmationReference || submissionConfirmation.method}
                    </p>
                  ) : null}
                  <div className="rounded-lg border border-blue-100 bg-white p-3">
                    <p className="text-xs font-black uppercase text-slate-500">{t("intentsPage.confirmationHistory")}</p>
                    {submissionConfirmations.length > 0 ? (
                      <ul className="mt-2 space-y-2">
                        {submissionConfirmations.map((confirmation) => {
                          const frozenExports = confirmation.evidenceSnapshot.responsePackageExports;

                          return (
                            <li key={confirmation.id} className="text-sm font-semibold leading-6 text-slate-700">
                              <span className="font-black text-slate-950">
                                {confirmation.confirmationReference || t(`intentsPage.submissionMethods.${confirmation.method}`)}
                              </span>
                              <span className="text-slate-500"> · {confirmation.submittedAt}</span>
                              {confirmation.confirmationNotes ? (
                                <span className="block break-words text-slate-600">{confirmation.confirmationNotes}</span>
                              ) : null}
                              {frozenExports.length > 0 ? (
                                <div className="mt-2 rounded-md border border-slate-100 bg-slate-50 p-2">
                                  <p className="text-[11px] font-black uppercase text-slate-500">
                                    {t("intentsPage.submissionEvidenceFrozenAt")} · {formatEvidenceDate(confirmation.evidenceSnapshot.capturedAt)}
                                  </p>
                                  <ul className="mt-1 space-y-1">
                                    {frozenExports.map((exportRecord) => {
                                      const downloadUrl = safeSubmissionEvidenceUrl(exportRecord.downloadUrl);

                                      return (
                                        <li key={exportRecord.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-bold text-slate-600">
                                          <span className="font-black text-slate-900">
                                            {submissionPackageVersionLabel(t, exportRecord.snapshotVersionNumber)}
                                          </span>
                                          <span>{exportRecord.format}</span>
                                          <span>{t(`intentsPage.responsePackageExportReviewStatuses.${exportRecord.reviewStatus}`)}</span>
                                          <Link
                                            href={downloadUrl}
                                            target={downloadUrl.startsWith("/") ? undefined : "_blank"}
                                            rel={downloadUrl.startsWith("/") ? undefined : "noreferrer"}
                                            className="inline-flex items-center font-black text-blue-700 hover:text-blue-900"
                                          >
                                            <ExternalLink size={12} className="mr-1" aria-hidden="true" />
                                            {t("intentsPage.downloadEvidence")}
                                          </Link>
                                        </li>
                                      );
                                    })}
                                  </ul>
                                </div>
                              ) : null}
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p className="mt-2 text-sm font-semibold text-slate-500">{t("intentsPage.submissionUnavailable")}</p>
                    )}
                  </div>
                  <div className="rounded-lg border border-blue-100 bg-white p-3">
                    <p className="text-xs font-black uppercase text-slate-500">{t("intentsPage.submissionEvidence")}</p>
                    {hasSubmissionEvidenceLinks(submissionEvidenceLinks) ? (
                      <div className="mt-3 space-y-3">
                        {submissionEvidenceLinks.responsePackageExports.length > 0 ? (
                          <div>
                            <p className="text-xs font-black text-slate-500">
                              {t("intentsPage.submissionEvidencePackageExports")}
                            </p>
                            <ul className="mt-2 space-y-2">
                              {submissionEvidenceLinks.responsePackageExports.map((exportRecord) => {
                                const record = exportRecord as SubmissionEvidenceExport;
                                const downloadUrl = record.downloadUrl ? safeSubmissionEvidenceUrl(record.downloadUrl) : "";
                                const timestamp = record.downloadedAt ?? record.createdAt ?? "";

                                return (
                                  <li key={record.id} className="text-sm font-semibold leading-6 text-slate-700">
                                    <span className="font-black text-slate-950">{record.format}</span>
                                    {timestamp ? (
                                      <span className="text-slate-500"> · {formatEvidenceDate(timestamp)}</span>
                                    ) : null}
                                    {downloadUrl ? (
                                      <Link
                                        href={downloadUrl}
                                        target={downloadUrl.startsWith("/") ? undefined : "_blank"}
                                        rel={downloadUrl.startsWith("/") ? undefined : "noreferrer"}
                                        className="ml-2 inline-flex items-center font-black text-blue-700 hover:text-blue-900"
                                      >
                                        <ExternalLink size={13} className="mr-1" aria-hidden="true" />
                                        {t("intentsPage.downloadEvidence")}
                                      </Link>
                                    ) : null}
                                  </li>
                                );
                              })}
                            </ul>
                          </div>
                        ) : null}

                        {submissionEvidenceLinks.linkedSupplierArtifacts.length > 0 ? (
                          <div>
                            <p className="text-xs font-black text-slate-500">
                              {t("intentsPage.submissionEvidenceLinkedArtifacts")}
                            </p>
                            <ul className="mt-2 space-y-2">
                              {submissionEvidenceLinks.linkedSupplierArtifacts.map((artifact) => {
                                const record = artifact as SubmissionEvidenceArtifact;
                                const downloadUrl = safeSubmissionEvidenceUrl(
                                  record.downloadUrl || artifactDownloadUrl(intent?.id ?? intentId, record.id),
                                );
                                const title = record.name || record.fileName || record.id;
                                const details = [record.type ?? record.category, record.sizeLabel].filter(Boolean);

                                return (
                                  <li key={record.id} className="text-sm font-semibold leading-6 text-slate-700">
                                    <Link
                                      href={downloadUrl}
                                      target={downloadUrl.startsWith("/") ? undefined : "_blank"}
                                      rel={downloadUrl.startsWith("/") ? undefined : "noreferrer"}
                                      className="font-black text-blue-700 hover:text-blue-900"
                                    >
                                      {title}
                                    </Link>
                                    {details.length > 0 ? (
                                      <span className="text-slate-500"> · {details.join(" · ")}</span>
                                    ) : null}
                                  </li>
                                );
                              })}
                            </ul>
                          </div>
                        ) : null}

                        {submissionEvidenceLinks.awardOutcome ? (
                          <div>
                            <p className="text-xs font-black text-slate-500">
                              {t("intentsPage.submissionEvidenceAwardOutcome")}
                            </p>
                            <p className="mt-2 text-sm font-semibold leading-6 text-slate-700">
                              <span className="font-black text-slate-950">
                                {t(`intentsPage.awardStatuses.${submissionEvidenceLinks.awardOutcome.status}`)}
                              </span>
                              {submissionEvidenceLinks.awardOutcome.awardNoticeUrl ? (
                                <Link
                                  href={safeSubmissionEvidenceUrl(submissionEvidenceLinks.awardOutcome.awardNoticeUrl)}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="ml-2 inline-flex items-center font-black text-blue-700 hover:text-blue-900"
                                >
                                  <ExternalLink size={13} className="mr-1" aria-hidden="true" />
                                  {t("intentsPage.openAwardNotice")}
                                </Link>
                              ) : null}
                            </p>
                          </div>
                        ) : null}
                      </div>
                    ) : (
                      <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
                        {t("intentsPage.submissionEvidenceEmpty")}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      <section
        className={`winbids-panel complianceManifest rounded-lg border p-5 shadow-sm ${
          complianceManifestFeature.enabled ? "border-slate-200 bg-white" : "border-amber-200 bg-amber-50/60"
        }`}
      >
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700">
              {complianceManifestFeature.enabled
                ? t("intentsPage.complianceManifest")
                : t("intentsPage.nextPhasePreview")}
            </p>
            <h2 className="mt-1 flex items-center gap-2 text-2xl font-black text-slate-950">
              <FileCheck2 size={21} className="text-blue-700" aria-hidden="true" />
              {t("intentsPage.complianceManifest")}
            </h2>
          </div>
          <span className="w-fit rounded-full border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-black text-amber-700">
            {complianceManifestFeature.enabled
              ? complianceManifest
                ? `${complianceManifest.summary.completed}/${complianceManifest.summary.total} ${t("intentsPage.complianceComplete")}`
                : t("intentsPage.complianceLoading")
              : lockedFeatureMessage("compliance_manifest")}
          </span>
        </div>

        {!complianceManifestFeature.enabled ? (
          <LockedFeatureState
            message={lockedFeatureMessage("compliance_manifest")}
            title={t("intentsPage.complianceManifest")}
          />
        ) : (
          <div className="mt-5 space-y-4">
            <div className="grid gap-3 sm:grid-cols-4">
              {[
                ["total", complianceManifest?.summary.total ?? 0],
                ["completed", complianceManifest?.summary.completed ?? 0],
                ["blocked", complianceManifest?.summary.blocked ?? 0],
                ["evidenceAttached", complianceManifest?.summary.evidenceAttached ?? 0],
              ].map(([key, value]) => (
                <div key={key as string} className="rounded-lg border border-slate-200 bg-slate-50/70 p-3">
                  <p className="text-xs font-black uppercase text-slate-400">
                    {t(`intentsPage.complianceSummary.${key as string}`)}
                  </p>
                  <p className="mt-1 text-2xl font-black text-slate-950">{value}</p>
                </div>
              ))}
            </div>

            {isComplianceLoading ? (
              <p className="text-sm font-semibold text-slate-500">{t("intentsPage.complianceLoading")}</p>
            ) : (
              <div className="grid gap-3">
                {(complianceManifest?.items ?? []).map((item) => (
                  <article key={item.id} className="rounded-lg border border-slate-200 bg-white p-4">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge variant="outline" className="border-blue-100 bg-blue-50 text-blue-700">
                            {t(`intentsPage.complianceCategories.${item.category}`)}
                          </Badge>
                          {complianceSavingItemId === item.id && (
                            <span className="text-xs font-bold text-slate-400">
                              {t("intentsPage.submissionSaving")}
                            </span>
                          )}
                        </div>
                        <p className="mt-2 break-words text-sm font-black leading-6 text-slate-950">{item.title}</p>
                        {item.evidenceRefs.length > 0 ? (
                          <div className="mt-3">
                            <p className="text-xs font-black text-slate-500">{t("intentsPage.linkedEvidence")}</p>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {item.evidenceRefs.map((ref) => {
                                const url = evidenceRefUrl(ref);
                                const key = `${item.id}-${ref.kind}-${ref.citationId ?? ref.url ?? ref.label}`;
                                const chipClassName = "inline-flex min-h-7 items-center rounded-md border border-blue-100 bg-blue-50 px-2 py-1 text-xs font-black text-blue-700";

                                return url ? (
                                  <Link
                                    key={key}
                                    href={url}
                                    target={url.startsWith("/") ? undefined : "_blank"}
                                    rel={url.startsWith("/") ? undefined : "noreferrer"}
                                    className={`${chipClassName} hover:border-blue-200 hover:bg-white`}
                                  >
                                    <ExternalLink size={12} className="mr-1.5 shrink-0" aria-hidden="true" />
                                    <span className="break-words">{ref.label}</span>
                                  </Link>
                                ) : (
                                  <span key={key} className={`${chipClassName} bg-white text-slate-600`}>
                                    {ref.label}
                                  </span>
                                );
                              })}
                            </div>
                          </div>
                        ) : null}
                      </div>
                      <div className="grid gap-2 sm:grid-cols-2 lg:w-[360px]">
                        <Select
                          value={item.status}
                          onValueChange={(value) =>
                            void handleComplianceItemUpdate(item, { status: value as ComplianceItemStatus })
                          }
                          disabled={Boolean(complianceSavingItemId)}
                        >
                          <SelectTrigger className="h-9 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                            {complianceStatuses.map((status) => (
                              <SelectItem key={status} value={status}>
                                {t(`intentsPage.complianceStatuses.${status}`)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select
                          value={item.evidenceStatus}
                          onValueChange={(value) =>
                            void handleComplianceItemUpdate(item, { evidenceStatus: value as ComplianceEvidenceStatus })
                          }
                          disabled={Boolean(complianceSavingItemId)}
                        >
                          <SelectTrigger className="h-9 rounded-lg border-slate-200 bg-white shadow-sm focus:ring-slate-900">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="rounded-lg border-slate-200 shadow-lg">
                            {complianceEvidenceStatuses.map((status) => (
                              <SelectItem key={status} value={status}>
                                {t(`intentsPage.complianceEvidenceStatuses.${status}`)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <textarea
                      value={item.notes}
                      onChange={(event) => updateLocalComplianceItem(item.id, { notes: event.target.value })}
                      onBlur={(event) => void handleComplianceItemUpdate(item, { notes: event.currentTarget.value })}
                      disabled={Boolean(complianceSavingItemId)}
                      placeholder={t("intentsPage.complianceNotesPlaceholder")}
                      className="mt-3 min-h-16 w-full resize-y rounded-lg border border-slate-200 bg-slate-50/60 px-3 py-2 text-sm outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10"
                    />
                  </article>
                ))}
              </div>
            )}

            <p className="min-h-5 text-sm font-semibold text-slate-500">
              {complianceError
                ? t("intentsPage.complianceSaveError")
                : complianceNotice}
            </p>
          </div>
        )}
      </section>

      <section className="grid gap-3 md:grid-cols-4">
        {pursuitLanes.map((lane) => (
          <article key={lane.key} className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-sm font-black text-slate-950">
                {t(`intentsPage.pipeline.${lane.key}`)}
              </h3>
              <span className="grid h-6 min-w-7 place-items-center rounded-full bg-violet-50 px-2 text-xs font-black text-violet-700">
                {lane.count}
              </span>
            </div>
            <div className="mt-3 grid gap-2">
              {lane.items.map((item) => (
                <div key={item} className="rounded-lg border border-slate-100 bg-slate-50/70 p-3 text-xs font-bold text-slate-600">
                  {t(`intentsPage.pipelineItems.${item}`)}
                </div>
              ))}
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
