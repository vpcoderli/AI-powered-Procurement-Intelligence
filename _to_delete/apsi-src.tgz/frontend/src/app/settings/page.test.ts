import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("settings page", () => {
  it("surfaces current plan, usage limits, checkout upgrades, and locked feature guidance", () => {
    const page = readFileSync(new URL("page.tsx", import.meta.url), "utf8");

    expect(page).toContain("ACCOUNT_TIER_LABELS[user.tier]");
    expect(page).toContain("currentTier");
    expect(page).toContain("usageLimitedItems");
    expect(page).toContain("settings.usageRemaining");
    expect(page).toContain("settings.unlimitedUsage");
    expect(page).toContain("createCheckoutSession");
    expect(page).toContain("settings.startCheckout");
    expect(page).toContain("FEATURE_ACCESS_ITEMS.map");
    expect(page).toContain("canUseFeature(user, feature.key)");
    expect(page).toContain("lockedFeatureMessage(feature.key)");
    expect(page).toContain("pursue_no_bid");
    expect(page).toContain("bid.brief.full.generate");
    expect(page).toContain("response.workspace.create");
    expect(page).toContain("artifact.vault.upload");
    expect(page).toContain("SettingsInlineState");
    expect(page).toContain('code="plan_limit"');
  });

  it("uses the shared upgrade lock message for premium settings features", () => {
    const page = readFileSync(new URL("page.tsx", import.meta.url), "utf8");

    expect(page).toContain("const deadlineReminderLockedMessage = lockedFeatureMessage(\"deadline_notifications\")");
    expect(page).toContain("message={deadlineReminderLockedMessage}");
    expect(page).toContain("return deadlineReminderLockedMessage;");
    expect(page).not.toContain('message={t("settings.reminderCenterLockedMessage")}');
    expect(page).not.toContain('? t("settings.reminderCenterLockedMessage")');
  });

  it("shows the current account tier and feature access states", () => {
    const page = readFileSync(new URL("page.tsx", import.meta.url), "utf8");

    expect(page).toContain("useAuth");
    expect(page).toContain("FEATURE_ACCESS_ITEMS");
    expect(page).toContain("canUseFeature");
    expect(page).toContain("lockedFeatureMessage");
    expect(page).toContain("settings.currentPlan");
    expect(page).toContain("settings.featureAccess");
    expect(page).toContain("deadline_notifications");
    expect(page).toContain("settings.usageDashboard");
    expect(page).toContain("settings.usageRemaining");
    expect(page).toContain("settings.usageFeature_search_alerts");
    expect(page).toContain("settings.usageFeature_team_members");
    expect(page).toContain("settings.usageDashboardSummary");
    expect(page).toContain("usageLimitedItems");
    expect(page).toContain("usageData");
    expect(page).toContain("settings.creditSummary");
    expect(page).toContain("settings.creditSummaryValue");
    expect(page).toContain("settings.includedCredits");
    expect(page).toContain("settings.plannedPlan");
    expect(page).toContain("productPlanKey");
    expect(page).toContain("updateAccountProfile");
    expect(page).toContain("changePassword");
    expect(page).toContain("exportAccountData");
    expect(page).toContain("deleteAccount");
    expect(page).toContain("fetchAccountSubscription");
    expect(page).toContain("fetchAccountUsage");
    expect(page).toContain("fetchAccountNotificationPreferences");
    expect(page).toContain("updateAccountNotificationPreferences");
    expect(page).toContain("fetchAccountDeadlineReminders");
    expect(page).toContain("updateAccountDeadlineReminder");
    expect(page).toContain("deadlineReminderCenter");
    expect(page).toContain("handleDeadlineReminderAction");
    expect(page).toContain("settings.reminderCenter");
    expect(page).toContain("settings.acknowledgeReminder");
    expect(page).toContain("settings.snoozeReminder");
    expect(page).toContain("listSearchAlerts");
    expect(page).toContain("createSearchAlert");
    expect(page).toContain("updateSearchAlert");
    expect(page).toContain("deleteSearchAlert");
    expect(page).toContain("fetchBillingInvoices");
    expect(page).toContain("createBillingPortalSession");
    expect(page).toContain("createCheckoutSession");
    expect(page).toContain("cancelAccountSubscription");
    expect(page).toContain("fetchAccountWorkspace");
    expect(page).toContain("updateAccountWorkspace");
    expect(page).toContain("inviteWorkspaceMember");
    expect(page).toContain("resendWorkspaceInvitation");
    expect(page).toContain("revokeWorkspaceInvitation");
    expect(page).toContain("updateWorkspaceMemberRole");
    expect(page).toContain("setWorkspaceMemberStatus");
    expect(page).toContain("transferWorkspaceOwnership");
    expect(page).toContain("removeWorkspaceMember");
    expect(page).toContain("user?.email");
    expect(page).toContain("workspaceData");
    expect(page).toContain("settings.team");
    expect(page).toContain("settings.inviteMember");
    expect(page).toContain("settings.teamSeatLimitReached");
    expect(page).toContain("settings.inviteUrl");
    expect(page).toContain("settings.inviteDelivery");
    expect(page).toContain("invitationDelivery");
    expect(page).toContain("settings.changeRole");
    expect(page).toContain("settings.removeMember");
    expect(page).toContain("settings.disableMember");
    expect(page).toContain("settings.restoreMember");
    expect(page).toContain("settings.resendInvite");
    expect(page).toContain("settings.revokeInvite");
    expect(page).toContain("settings.inviteResent");
    expect(page).toContain("settings.inviteRevoked");
    expect(page).toContain("settings.inviteUrl");
    expect(page).toContain("settings.memberUpdated");
    expect(page).toContain("settings.memberRemoved");
    expect(page).toContain("settings.transferOwnership");
    expect(page).toContain("settings.exportAccountData");
    expect(page).toContain("settings.deleteAccount");
    expect(page).toContain("settings.ownerTransferRequired");
    expect(page).toContain("displayName");
    expect(page).toContain("refreshSession");
    expect(page).toContain("settings.billing");
    expect(page).toContain("settings.availablePlans");
    expect(page).toContain("settings.startCheckout");
    expect(page).toContain("settings.checkoutStarted");
    expect(page).toContain("settings.cancelSubscription");
    expect(page).toContain("settings.invoiceHistory");
    expect(page).toContain("settings.noInvoices");
    expect(page).toContain("settings.viewInvoice");
    expect(page).toContain("settings.viewInvoicePdf");
    expect(page).toContain("settings.invoiceFilter");
    expect(page).toContain("settings.invoiceSummary");
    expect(page).toContain("billingInvoiceStatusFilter");
    expect(page).toContain("billingInvoicesData?.summary");
    expect(page).toContain("settings.pastDueBillingWarning");
    expect(page).toContain("settings.retryPayment");
    expect(page).toContain("settings.manageBilling");
    expect(page).toContain("settings.portalStarted");
    expect(page).toContain("notificationPreferences");
    expect(page).toContain("settings.notificationPreferencesSaved");
    expect(page).toContain("searchAlertsData");
    expect(page).toContain("settings.searchAlertsManager");
    expect(page).toContain("settings.createSearchAlert");
    expect(page).toContain("settings.editSearchAlert");
    expect(page).toContain("settings.pauseSearchAlert");
    expect(page).toContain("settings.resumeSearchAlert");
    expect(page).toContain("settings.deleteSearchAlert");
    expect(page).toContain("settings.searchAlertSaved");
    expect(page).toContain("settings.searchAlertDeleted");
    expect(page).toContain("settings.searchAlertLimitReached");
    expect(page).toContain("settings.searchAlertDeliveryHistory");
    expect(page).toContain("settings.searchAlertNoDeliveryHistory");
    expect(page).toContain("settings.searchAlertDigestStatus_sent");
    expect(page).toContain("settings.searchAlertDigestSkipped_notifications_disabled");
    expect(page).toContain("digestHistory");
    expect(page).toContain("handleSearchAlertSubmit");
    expect(page).toContain("handleSearchAlertToggle");
    expect(page).toContain("handleSearchAlertDelete");
  });

  it("uses UniversalState for settings loading, error, and plan-limit states", () => {
    const page = readFileSync(new URL("page.tsx", import.meta.url), "utf8");

    expect(page).toContain('import { UniversalState } from "@/components/universal-state"');
    expect(page).toContain('code="loading"');
    expect(page).toContain('code="error"');
    expect(page).toContain('code="plan_limit"');
    expect(page).toContain("SettingsInlineState");
  });

  it("shows an auth-required state before rendering account settings", () => {
    const page = readFileSync(new URL("page.tsx", import.meta.url), "utf8");

    expect(page).toContain("AuthRequiredState");
    expect(page).toContain("if (!user)");
    expect(page).toContain("settings.accountRequiresLogin");
  });

  it("navigates to hosted checkout URLs with real browser navigation", () => {
    const page = readFileSync(new URL("page.tsx", import.meta.url), "utf8");

    expect(page).toContain("window.location.assign(result.checkoutSession.checkoutUrl)");
    expect(page).not.toContain("window.history.replaceState(null, \"\", result.checkoutSession.checkoutUrl)");
  });
});
