import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { CREDIT_ACTIONS, creditAllowanceForTier, creditCostForFeature } from "@/server/billing/credits";
import { alerts, bids, intentToBid, organizationMemberships, organizations, savedBids, users } from "@/server/db/schema";
import { createTestDatabase, type TestDatabase } from "@/server/db/test-utils";
import {
  UsageLimitError,
  enforceMysqlSearchAlertUsageLimit,
  enforceUsageLimit,
  getUsageLimitStatus,
  usageLimitForTier,
} from "./usage-limits";

describe("usage limits", () => {
  let testDb: TestDatabase;

  beforeEach(async () => {
    testDb = await createTestDatabase({ seed: false });
    testDb.db.insert(users).values({
      id: "user_free",
      email: "free@example.com",
      role: "user",
      accountTier: "free",
      createdAt: "2026-05-28T00:00:00.000Z",
      updatedAt: "2026-05-28T00:00:00.000Z",
    }).run();
    for (let index = 1; index <= 6; index += 1) {
      testDb.db.insert(bids).values({
        id: `bid_${index}`,
        source: "SAM.gov",
        sourceBidId: `mock:${index}`,
        dedupeKey: `mock:${index}`,
        title: `Bid ${index}`,
        description: "Short description",
        issuerName: "Agency",
        issuerType: "federal",
        stateCode: "US",
        sourceUrl: "https://example.com",
        firstSeenAt: "2026-05-28T00:00:00.000Z",
        lastSeenAt: "2026-05-28T00:00:00.000Z",
        createdAt: "2026-05-28T00:00:00.000Z",
        updatedAt: "2026-05-28T00:00:00.000Z",
      }).run();
    }
  });

  afterEach(async () => {
    await testDb.cleanup();
  });

  it("reports tier limits for countable features", () => {
    expect(usageLimitForTier("free", "saved_bids")).toBe(5);
    expect(usageLimitForTier("free", "intent_workspace")).toBe(2);
    expect(usageLimitForTier("free", "search_alerts")).toBe(2);
    expect(usageLimitForTier("free", "team_members")).toBe(1);
    expect(usageLimitForTier("business", "team_members")).toBe(10);
    expect(usageLimitForTier("enterprise", "saved_bids")).toBeNull();
  });

  it("covers included credit allowances without enforcing live consumption", () => {
    expect(creditAllowanceForTier("free")).toBe(0);
    expect(creditAllowanceForTier("pro")).toBe(25);
    expect(creditAllowanceForTier("business")).toBe(150);
    expect(creditAllowanceForTier("enterprise")).toBeNull();
  });

  it("covers static premium action credit cost metadata", () => {
    expect(CREDIT_ACTIONS["bid.brief.full.generate"]).toMatchObject({
      feature: "bid.brief.full.generate",
      creditCost: 1,
      refundOnSystemFailure: true,
    });
    expect(CREDIT_ACTIONS["response.section.draft"]).toMatchObject({
      feature: "response.section.draft",
      creditCost: 3,
      refundOnSystemFailure: true,
    });
    expect(CREDIT_ACTIONS["package.review.run"]).toMatchObject({
      feature: "package.review.run",
      creditCost: 4,
      refundOnSystemFailure: true,
    });
    expect(creditCostForFeature("bid_search")).toBe(0);
  });

  it("allows free users under the saved bid limit and rejects new saves at the limit", () => {
    for (let index = 1; index <= 5; index += 1) {
      testDb.db.insert(savedBids).values({
        userId: "user_free",
        bidId: `bid_${index}`,
        createdAt: `2026-05-28T00:00:0${index}.000Z`,
      }).run();
    }

    expect(
      getUsageLimitStatus(testDb.db, "user_free", "free", "saved_bids"),
    ).toMatchObject({ used: 5, limit: 5, remaining: 0, isLimited: true });
    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_free",
        tier: "free",
        feature: "saved_bids",
        resourceId: "bid_6",
      }),
    ).toThrow(UsageLimitError);
    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_free",
        tier: "free",
        feature: "saved_bids",
        resourceId: "bid_1",
      }),
    ).not.toThrow();
  });

  it("rejects new intent workspaces at the free limit", () => {
    for (let index = 1; index <= 2; index += 1) {
      testDb.db.insert(intentToBid).values({
        id: `intent_${index}`,
        userId: "user_free",
        bidId: `bid_${index}`,
        status: "intent_added",
        aiBidBrief: "Brief",
        keyDatesJson: "{}",
        initialChecklistJson: "[]",
        riskFlagsJson: "[]",
        matchScoreSnapshotJson: "{}",
        createdAt: `2026-05-28T00:00:0${index}.000Z`,
        updatedAt: `2026-05-28T00:00:0${index}.000Z`,
      }).run();
    }

    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_free",
        tier: "free",
        feature: "intent_workspace",
        resourceId: "bid_3",
      }),
    ).toThrow(UsageLimitError);
    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_free",
        tier: "free",
        feature: "intent_workspace",
        resourceId: "bid_1",
      }),
    ).not.toThrow();
  });

  it("counts existing resources across a workspace scope", () => {
    testDb.db.insert(users).values({
      id: "user_member",
      email: "member@example.com",
      role: "user",
      accountTier: "free",
      createdAt: "2026-05-28T00:00:00.000Z",
      updatedAt: "2026-05-28T00:00:00.000Z",
    }).run();
    testDb.db.insert(organizations).values({
      id: "org_1",
      name: "Workspace",
      createdAt: "2026-05-28T00:00:00.000Z",
      updatedAt: "2026-05-28T00:00:00.000Z",
    }).run();
    for (const userId of ["user_free", "user_member"]) {
      testDb.db.insert(organizationMemberships).values({
        organizationId: "org_1",
        userId,
        role: userId === "user_free" ? "owner" : "member",
        status: "active",
        createdAt: "2026-05-28T00:00:00.000Z",
        updatedAt: "2026-05-28T00:00:00.000Z",
      }).run();
    }
    for (let index = 1; index <= 5; index += 1) {
      testDb.db.insert(savedBids).values({
        userId: index % 2 === 0 ? "user_member" : "user_free",
        bidId: `bid_${index}`,
        createdAt: `2026-05-28T00:00:0${index}.000Z`,
      }).run();
    }

    expect(
      getUsageLimitStatus(testDb.db, "user_member", "free", "saved_bids", {
        scopeUserIds: ["user_free", "user_member"],
      }),
    ).toMatchObject({ used: 5, limit: 5, isLimited: true });
    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_member",
        tier: "free",
        feature: "saved_bids",
        resourceId: "bid_6",
        scopeUserIds: ["user_free", "user_member"],
      }),
    ).toThrow(UsageLimitError);
    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_member",
        tier: "free",
        feature: "saved_bids",
        resourceId: "bid_1",
        scopeUserIds: ["user_free", "user_member"],
      }),
    ).not.toThrow();
  });

  it("counts search alerts and team members across a workspace scope", () => {
    testDb.db.insert(users).values({
      id: "user_member",
      email: "member@example.com",
      role: "user",
      accountTier: "free",
      createdAt: "2026-05-28T00:00:00.000Z",
      updatedAt: "2026-05-28T00:00:00.000Z",
    }).run();
    testDb.db.insert(organizations).values({
      id: "org_1",
      name: "Workspace",
      createdAt: "2026-05-28T00:00:00.000Z",
      updatedAt: "2026-05-28T00:00:00.000Z",
    }).run();
    for (const userId of ["user_free", "user_member"]) {
      testDb.db.insert(organizationMemberships).values({
        organizationId: "org_1",
        userId,
        role: userId === "user_free" ? "owner" : "member",
        status: "active",
        createdAt: "2026-05-28T00:00:00.000Z",
        updatedAt: "2026-05-28T00:00:00.000Z",
      }).run();
      testDb.db.insert(alerts).values({
        id: `alert_${userId}`,
        userId,
        name: `Alert ${userId}`,
        query: JSON.stringify({ q: "cloud" }),
        states: "[]",
        issuerType: "all",
        deadlinePreset: "any",
        publishedPreset: "any",
        frequency: "daily",
        isEnabled: 1,
        createdAt: "2026-05-28T00:00:00.000Z",
        updatedAt: "2026-05-28T00:00:00.000Z",
      }).run();
    }

    expect(
      getUsageLimitStatus(testDb.db, "user_free", "free", "search_alerts", {
        scopeUserIds: ["user_free", "user_member"],
      }),
    ).toMatchObject({ used: 2, limit: 2, remaining: 0, isLimited: true, requiredTier: "pro" });
    expect(
      getUsageLimitStatus(testDb.db, "user_free", "free", "team_members", {
        scopeUserIds: ["user_free", "user_member"],
      }),
    ).toMatchObject({ used: 2, limit: 1, remaining: 0, isLimited: true, requiredTier: "business" });
    expect(() =>
      enforceUsageLimit(testDb.db, {
        userId: "user_free",
        tier: "free",
        feature: "search_alerts",
        scopeUserIds: ["user_free", "user_member"],
      }),
    ).toThrow(UsageLimitError);
  });

  it("enforces the MySQL search alert quota", async () => {
    const mysql = {
      query: vi.fn(async (sql: string) => {
        if (sql.includes("organization_memberships")) {
          return [[{ userId: "user_free" }], []];
        }
        if (sql.includes("COUNT")) {
          return [[{ used: 2 }], []];
        }
        return [[], []];
      }),
    };

    await expect(
      enforceMysqlSearchAlertUsageLimit(mysql, {
        userId: "user_free",
        tier: "free",
      }),
    ).rejects.toThrow(UsageLimitError);
  });
});
